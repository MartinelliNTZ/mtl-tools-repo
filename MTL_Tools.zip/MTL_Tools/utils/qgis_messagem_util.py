# -*- coding: utf-8 -*-
"""
Qgis Message Utility

Classe utilitária para exibição de mensagens no QGIS (modal e não-modal), com
vários tipos (erro, sucesso, informação, aviso, debug) e funções auxiliares para
confirmação e log. Projetada para ser usada por plugins e scripts que tenham
acesso ao `iface` (QgisInterface).

Recursos principais
-------------------
- Mensagens modais (QMessageBox): interrompem o fluxo e exigem interação do
  usuário.
- Mensagens não-modais (Message Bar): aparecem na barra de mensagens do QGIS
  e desaparecem automaticamente (úteis para notificações leves).
- Integração com QgsMessageLog para registro persistente no log do QGIS.
- Helpers para exibir exceções formatadas e mensagens de debug.

Como usar
---------
1) Importe a classe no seu plugin/script:

    from qgis_utils.message import QgisMessageUtil

2) Use os métodos estáticos diretamente passando `iface` e a string:

    QgisMessageUtil.modal_info(iface, "Operação concluída com sucesso")
    QgisMessageUtil.bar_success(iface, "CSV salvo")

3) Para confirmar antes de agir:

    if QgisMessageUtil.confirm(iface, "Deseja continuar?"):
        do_action()

Tipos de mensagens
------------------
- Modal: info, success (info com ícone de informação), warning, error, debug.
- Message bar: info, success, warning, critical (curta duração, não bloqueante).
- Log: escreve no log do QGIS (útil para depuração prolongada).

Outros canais
-------------
- Status bar (iface.mainWindow().statusBar()) — para mensagens muito discretas.
- Notificações do sistema (não implementadas aqui) — exigir bibliotecas externas.

API resumida
-------------
- modal_info / modal_success / modal_warning / modal_error / modal_debug
- bar_info / bar_success / bar_warning / bar_critical
- confirm (Yes/No)
- show_exception (formata traceback e mostra modal + log)
- log (escreve no QgsMessageLog)

Detalhes de implementação
-------------------------
- Message bar usa `iface.messageBar().pushMessage(title, text, level, duration)`
  onde `level` é um dos: QgisMessageBar.INFO, WARNING, CRITICAL.
- Modal usa QMessageBox com ícones e botões apropriados.
- show_exception captura traceback e oferece opção de copiar detalhes.

Exemplos
--------
- Mensagem de sucesso não modal:

    QgisMessageUtil.bar_success(iface, "Export concluído", duration=5)

- Mensagem de erro modal com detalhe:

    try:
        risky()
    except Exception as e:
        QgisMessageUtil.show_exception(iface, e, "Falha ao processar camada")

- Debug (exibe ambiente e escreve no log):

    QgisMessageUtil.modal_debug(iface, f"sys.executable={sys.executable}")


Implementação
--------------
"""
import traceback
from qgis.core import Qgis, QgsMessageLog
from qgis.PyQt.QtWidgets import QMessageBox
from qgis.PyQt.QtCore import Qt


class QgisMessageUtil:
    """Utilitário estático para exibir mensagens no QGIS.

    Todos os métodos aceitam `iface` (QgisInterface) como primeiro argumento.
    """

    DEFAULT_LOG_TAG = "MTL_Tools"

    # ------------------------------
    # Message bar (não modal)
    # ------------------------------
    @staticmethod
    def _push_message_bar(iface, title, message, level=Qgis.Info, duration=3):
        """Push uma mensagem na message bar do QGIS.

        Parameters
        ----------
        iface : QgisInterface
        title : str
        message : str
        level : Qgis.MessageLevel (Qgis.Info/Qgis.Warning/Qgis.Critical)
        duration : int (segundos)
        """
        # iface.messageBar pode não existir em alguns contextos; tente capturar
        try:
            iface.messageBar().pushMessage(title, message, level, duration)
        except Exception:
            # fallback para QMessageBox modal se messageBar não estiver disponível
            QMessageBox.information(iface.mainWindow(), title, message)

    @staticmethod
    def bar_info(iface, message, title="Info", duration=3):
        QgisMessageUtil._push_message_bar(iface, title, message, Qgis.Info, duration)

    @staticmethod
    def bar_success(iface, message, title="Sucesso", duration=3):
        # não existe 'Success' em Qgis, usar Info com título Sucesso
        QgisMessageUtil._push_message_bar(iface, title, message, Qgis.Info, duration)

    @staticmethod
    def bar_warning(iface, message, title="Aviso", duration=5):
        QgisMessageUtil._push_message_bar(iface, title, message, Qgis.Warning, duration)

    @staticmethod
    def bar_critical(iface, message, title="Erro", duration=5):
        QgisMessageUtil._push_message_bar(iface, title, message, Qgis.Critical, duration)

    # ------------------------------
    # Modals (bloqueantes)
    # ------------------------------
    @staticmethod
    def modal_info(iface, message, title="Informação"):
        QMessageBox.information(iface.mainWindow(), title, message)

    @staticmethod
    def modal_success(iface, message, title="Sucesso"):
        # idem info, mas semântica de sucesso
        QMessageBox.information(iface.mainWindow(), title, message)

    @staticmethod
    def modal_warning(iface, message, title="Aviso"):
        QMessageBox.warning(iface.mainWindow(), title, message)

    @staticmethod
    def modal_error(iface, message, title="Erro"):
        QMessageBox.critical(iface.mainWindow(), title, message)

    @staticmethod
    def modal_debug(iface, message, title="Debug"):
        # exibe e também grava no log
        QMessageBox.information(iface.mainWindow(), title, str(message))
        QgisMessageUtil.log(str(message), level=Qgis.Info)

    # ------------------------------
    # Confirmação
    # ------------------------------
    @staticmethod
    def confirm(iface, message, title="Confirmação"):
        resp = QMessageBox.question(
            iface.mainWindow(), title, message,
            QMessageBox.Yes | QMessageBox.No, QMessageBox.No
        )
        return resp == QMessageBox.Yes

    # ------------------------------
    # Exceções e log
    # ------------------------------
    @staticmethod
    def show_exception(iface, exc: Exception, user_message: str = "Erro"):
        """Mostra uma modal com mensagem amigável e adiciona detalhes ao log.

        A caixa modal oferece o resumo (user_message) e um botão para mostrar
        detalhes (traceback) no console/log. Sempre registra o traceback no log
        do QGIS.
        """
        tb = traceback.format_exception(type(exc), exc, exc.__traceback__)
        tb_text = "".join(tb)
        # registrar no log do QGIS
        QgisMessageUtil.log(tb_text, level=Qgis.Critical)
        # mostrar resumo ao usuário
        QMessageBox.critical(iface.mainWindow(), user_message, str(exc))

    @staticmethod
    def log(message, level=Qgis.Info, tag=None):
        """Escreve no log do QGIS (QgsMessageLog)."""
        QgsMessageLog.logMessage(str(message), tag or QgisMessageUtil.DEFAULT_LOG_TAG, level)
        
    from qgis.PyQt.QtWidgets import QMessageBox

    @staticmethod
    def ask_field_conflict(iface, field_name):
        msg = QMessageBox(iface.mainWindow())
        msg.setIcon(QMessageBox.Question)
        msg.setWindowTitle("Campo existente")
        msg.setText(f"O campo '{field_name}' já existe.\nO que deseja fazer?")

        btn_replace = msg.addButton("Substituir", QMessageBox.AcceptRole)
        btn_rename = msg.addButton("Renomear", QMessageBox.ActionRole)
        btn_cancel = msg.addButton("Cancelar", QMessageBox.RejectRole)

        msg.exec()

        clicked = msg.clickedButton()
        if clicked == btn_replace:
            return "replace"
        if clicked == btn_rename:
            return "rename"
        return "cancel"



# EOF

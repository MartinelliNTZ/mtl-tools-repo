# -*- coding: utf-8 -*-
from qgis.core import (
    QgsVectorLayer, QgsFeature,
    QgsGeometry, QgsPointXY
)
import os


class VectorUtils:

    @staticmethod
    def merge_layers(layers, name="MERGE"):
        if not layers:
            return None

        crs = layers[0].crs().authid()
        out = QgsVectorLayer(
            f"{layers[0].geometryType()}?crs={crs}",
            name, "memory"
        )

        prov = out.dataProvider()
        prov.addAttributes(layers[0].fields())
        out.updateFields()

        out.startEditing()
        for lyr in layers:
            for f in lyr.getFeatures():
                prov.addFeature(f)
        out.commitChanges()
        out.updateExtents()
        return out

    @staticmethod
    def points_to_path(points, name="Trilha"):
        if len(points) < 2:
            return None

        line = QgsVectorLayer(
            "LineString?crs=EPSG:4326", name, "memory"
        )

        geom = QgsGeometry.fromPolylineXY([
            QgsPointXY(p["lon"], p["lat"]) for p in points
        ])

        f = QgsFeature()
        f.setGeometry(geom)
        line.dataProvider().addFeature(f)
        line.updateExtents()
        return line
    @staticmethod
    def save_layer(layer, output_path):
        from qgis.core import (
            QgsVectorFileWriter,
            QgsProject,
            QgsVectorLayer,
            QgsCoordinateReferenceSystem,
            QgsCoordinateTransform,
            QgsFeature
        )
        from ..utils.log_utils import LogUtils
        import os

        LogUtils.log("drone_coordinates", f"save_layer chamado → {output_path}")

        if layer is None or not output_path:
            LogUtils.log("drone_coordinates", "Layer ou output_path inválido")
            return None

        ext = os.path.splitext(output_path)[1].lower()

        driver_map = {
            ".shp": "ESRI Shapefile",
            ".gpkg": "GPKG",
            ".geojson": "GeoJSON",
            ".json": "GeoJSON",
            ".kml": "KML"
        }

        driver = driver_map.get(ext)
        if not driver:
            LogUtils.log("drone_coordinates", f"Extensão não suportada: {ext}")
            return None

        LogUtils.log("drone_coordinates", f"Driver: {driver}")
        LogUtils.log("drone_coordinates", f"CRS: {layer.crs().authid()}")
        LogUtils.log("drone_coordinates", f"Features: {layer.featureCount()}")

        # 🔁 Reprojeção real para KML
        if driver == "KML" and layer.crs().authid() != "EPSG:4326":
            LogUtils.log("drone_coordinates", "Reprojetando para EPSG:4326")

            target_crs = QgsCoordinateReferenceSystem("EPSG:4326")
            transform = QgsCoordinateTransform(
                layer.crs(),
                target_crs,
                QgsProject.instance()
            )

            mem = QgsVectorLayer(
                f"{layer.geometryType()}?crs=EPSG:4326",
                layer.name(),
                "memory"
            )
            mem.dataProvider().addAttributes(layer.fields())
            mem.updateFields()

            feats = []
            for f in layer.getFeatures():
                nf = QgsFeature(mem.fields())
                nf.setAttributes(f.attributes())
                g = f.geometry()
                g.transform(transform)
                nf.setGeometry(g)
                feats.append(nf)

            mem.dataProvider().addFeatures(feats)
            mem.updateExtents()
            layer = mem

            LogUtils.log("drone_coordinates", "Reprojeção concluída")

        options = QgsVectorFileWriter.SaveVectorOptions()
        options.driverName = driver
        options.fileEncoding = "UTF-8"

        LogUtils.log("drone_coordinates", "Chamando writeAsVectorFormatV3")

        result = QgsVectorFileWriter.writeAsVectorFormatV3(
            layer,
            output_path,
            QgsProject.instance().transformContext(),
            options
        )

        # ✅ Compatibilidade total entre versões
        if isinstance(result, tuple):
            err_code = result[0]
            err_msg = result[1] if len(result) > 1 else ""
        else:
            err_code = result
            err_msg = ""

        if err_code != QgsVectorFileWriter.NoError:
            LogUtils.log(
                "drone_coordinates",
                f"ERRO AO SALVAR ({err_code}): {err_msg}"
            )
            return None

        LogUtils.log("drone_coordinates", f"Arquivo salvo com sucesso: {output_path}")

        saved_layer = QgsVectorLayer(
            output_path,
            os.path.basename(output_path),
            "ogr"
        )

        if not saved_layer.isValid():
            LogUtils.log("drone_coordinates", "Layer salvo é inválido")
            return None

        LogUtils.log("drone_coordinates", "Layer carregado com sucesso")
        return saved_layer

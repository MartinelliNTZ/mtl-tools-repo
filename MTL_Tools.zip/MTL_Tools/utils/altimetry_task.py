# -*- coding: utf-8 -*-
from qgis.core import QgsTask, Qgis
from qgis.utils import iface
import json
import urllib.request


class AltimetriaTask(QgsTask):
    """
    Consulta altimetria usando OpenTopoData (SRTM 90m)
    API rápida, sem chave e estável
    """

    def __init__(self, lat, lon, callback):
        super().__init__("Consultando Altimetria (SRTM 90m)", QgsTask.CanCancel)
        self.lat = lat
        self.lon = lon
        self.callback = callback
        self.altitude = None
        self.error = None

    def run(self):
        try:
            url = (
                "https://api.opentopodata.org/v1/srtm90m"
                f"?locations={self.lat},{self.lon}"
            )

            with urllib.request.urlopen(url, timeout=15) as response:
                raw = response.read().decode("utf-8")
                data = json.loads(raw)

            # -----------------------------
            # Validação da resposta
            # -----------------------------
            if data.get("status") != "OK":
                self.error = "Status inválido da API"
                return False

            results = data.get("results", [])
            if not results:
                self.error = "Nenhum resultado retornado"
                return False

            elevation = results[0].get("elevation")
            if elevation is None:
                self.error = "Elevação não encontrada"
                return False

            self.altitude = float(elevation)
            return True

        except Exception as e:
            self.error = str(e)
            return False

    def finished(self, success):
        iface.messageBar().pushMessage(
            "DEBUG",
            "finished() foi chamado",
            level=Qgis.Info,
            duration=3
        )

        if success:
            self.callback(self.altitude, None)
            iface.messageBar().pushMessage(
                "Sucesso",
                "Altitude obtida com sucesso.",
                level=Qgis.Info,
                duration=2
            )
        else:
            iface.messageBar().pushMessage(
                "Altimetria",
                f"Falha ao obter altitude: {self.error}",
                level=Qgis.Warning,
                duration=5
            )
            self.callback(None, self.error)

def classFactory(iface):
    from .mtl_tools_plugin  import MTL_Tools
    return MTL_Tools(iface)

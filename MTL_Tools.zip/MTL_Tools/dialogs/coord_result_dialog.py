# -*- coding: utf-8 -*-
from qgis.PyQt.QtWidgets import (
    QDialog, QVBoxLayout, QLabel,
    QPushButton, QHBoxLayout, QLineEdit, QGroupBox
)
from qgis.PyQt.QtGui import QGuiApplication


class CoordResultDialog(QDialog):

    def __init__(self, iface, info):
        super().__init__(iface.mainWindow())
        self.setWindowTitle("Coordenadas do Ponto")
        self.setMinimumWidth(600)
        self.alt_edit = None


        layout = QVBoxLayout()

        # ==================================================
        # GRUPO WGS 84
        # ==================================================
        grp_wgs = QGroupBox("WGS 84 (EPSG:4326)")
        wgs_layout = QVBoxLayout()

        self.lat_dec = self._coord_line(
            f"{info['lat']:.8f}", "Latitude (Decimal)"
        )
        self.lon_dec = self._coord_line(
            f"{info['lon']:.8f}", "Longitude (Decimal)"
        )

        self.lat_dms = self._coord_line(
            info['lat_dms'], "Latitude (DMS)"
        )
        self.lon_dms = self._coord_line(
            info['lon_dms'], "Longitude (DMS)"
        )

        wgs_layout.addLayout(self.lat_dec)
        wgs_layout.addLayout(self.lon_dec)
        wgs_layout.addLayout(self.lat_dms)
        wgs_layout.addLayout(self.lon_dms)

        wgs_layout.addWidget(QLabel(
            f"Zona UTM: {info['zona_num']}{info['zona_letra']} | "
            f"Hemisfério: {info['hemisferio']}"
        ))

        btn_copy_wgs = QPushButton("Copiar WGS 84 (Completo)")
        btn_copy_wgs.clicked.connect(
            lambda: self.copy_wgs84(info)
        )
        wgs_layout.addWidget(btn_copy_wgs)

        grp_wgs.setLayout(wgs_layout)
        layout.addWidget(grp_wgs)

        # ==================================================
        # GRUPO UTM SIRGAS 2000
        # ==================================================
        grp_utm = QGroupBox("UTM SIRGAS 2000")
        utm_layout = QVBoxLayout()

        utm_layout.addWidget(QLabel(
            f"Zona: {info['zona_num']}{info['zona_letra']} | "
            f"Hemisfério: {info['hemisferio']} | "
            f"EPSG:{info['epsg']}"
        ))

        self.utm_x = self._coord_line(
            f"{info['utm_x']:.3f}", "Easting (X)"
        )
        self.utm_y = self._coord_line(
            f"{info['utm_y']:.3f}", "Northing (Y)"
        )

        utm_layout.addLayout(self.utm_x)
        utm_layout.addLayout(self.utm_y)

        btn_copy_utm = QPushButton("Copiar UTM SIRGAS 2000 (Completo)")
        btn_copy_utm.clicked.connect(
            lambda: self.copy_utm(info)
        )
        utm_layout.addWidget(btn_copy_utm)

        grp_utm.setLayout(utm_layout)
        layout.addWidget(grp_utm)
        
        grp_alt = QGroupBox("Altimetria (ALOS – OpenTopography)")
        alt_layout = QVBoxLayout()

        self.alt_edit = QLineEdit("Carregando...")
        self.alt_edit.setReadOnly(True)

        alt_layout.addWidget(QLabel("Altitude aproximada (m)"))
        alt_layout.addWidget(self.alt_edit)

        grp_alt.setLayout(alt_layout)
        layout.addWidget(grp_alt)

        
        # ==================================================
        # FECHAR
        # ==================================================
        btn_close = QPushButton("Fechar")
        btn_close.clicked.connect(self.close)
        layout.addWidget(btn_close)

        self.setLayout(layout)

    # --------------------------------------------------
    # Linha padrão com botão copiar
    # --------------------------------------------------
    def _coord_line(self, value, label):
        h = QHBoxLayout()
        edit = QLineEdit(value)
        edit.setReadOnly(True)
        btn = QPushButton("Copiar")
        btn.clicked.connect(
            lambda: QGuiApplication.clipboard().setText(value)
        )
        h.addWidget(QLabel(label))
        h.addWidget(edit)
        h.addWidget(btn)
        return h

    # --------------------------------------------------
    # Copiar WGS84 completo
    # --------------------------------------------------
    def copy_wgs84(self, info):
        text = (
            "WGS 84 (EPSG:4326)\n"
            f"Latitude = {info['lat']:.8f}\n"
            f"Longitude = {info['lon']:.8f}\n"
            f"Latitude DMS = {info['lat_dms']}\n"
            f"Longitude DMS = {info['lon_dms']}\n"
            f"Zona UTM = {info['zona_num']}{info['zona_letra']}\n"
            f"Hemisfério = {info['hemisferio']}"
        )
        QGuiApplication.clipboard().setText(text)

    # --------------------------------------------------
    # Copiar UTM completo
    # --------------------------------------------------
    def copy_utm(self, info):
        text = (
            "UTM SIRGAS 2000\n"
            f"EPSG:{info['epsg']}\n"
            f"Zona={info['zona_num']}{info['zona_letra']}\n"
            f"Hemisfério={info['hemisferio']}\n"
            f"Easting={info['utm_x']:.3f}\n"
            f"Northing={info['utm_y']:.3f}"
        )
        QGuiApplication.clipboard().setText(text)
        
    def set_altitude(self, value):
        if value is None:
            self.alt_edit.setText("Indisponível")
        else:
            self.alt_edit.setText(f"{value:.2f} m")

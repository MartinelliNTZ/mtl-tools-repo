# -*- coding: utf-8 -*-
import os
import math
import statistics
from datetime import datetime

from qgis.PyQt.QtGui import QIcon
from qgis.PyQt.QtCore import QVariant

from qgis.core import (
    QgsProcessingAlgorithm,
    QgsProcessingParameterFeatureSource,
    QgsProcessingParameterField,
    QgsProcessingParameterString,
    QgsProcessingParameterFileDestination,
    QgsProcessingParameterNumber,
    QgsProcessingParameterBoolean,
    QgsProcessing,
    QgsFields,
    QgsField,
    QgsFeature,
    QgsFeatureSink,
    QgsWkbTypes,
    QgsProcessingException,
    QgsVectorLayer
)

# Preferências
from ..utils.preferences import load_tool_prefs, save_tool_prefs

TOOL_KEY = "attribute_stats_tool"


# --------------------------
# Preferências utilitárias
# --------------------------

def _load_prefs():
    prefs = load_tool_prefs(TOOL_KEY)
    return {
        "precision": int(prefs.get("precision", 4)),
        "exclude_fields": prefs.get("exclude_fields", []),
        "last_layer_source": prefs.get("last_layer_source", ""),
        "ptbr_format": bool(prefs.get("ptbr_format", False)),
        "load_after": bool(prefs.get("load_after", False)),
    }


def _save_prefs(precision, exclude_fields, layer_source, ptbr_format, load_after):
    save_tool_prefs(TOOL_KEY, {
        "precision": int(precision),
        "exclude_fields": exclude_fields,
        "last_layer_source": layer_source,
        "ptbr_format": bool(ptbr_format),
        "load_after": bool(load_after),
    })


def _percentile(sorted_vals, q):
    if not sorted_vals:
        return float("nan")
    n = len(sorted_vals)
    if n == 1:
        return float(sorted_vals[0])
    pos = (q / 100.0) * (n - 1)
    lo = int(math.floor(pos))
    hi = int(math.ceil(pos))
    if lo == hi:
        return float(sorted_vals[int(pos)])
    weight = pos - lo
    return float(sorted_vals[lo] * (1 - weight) + sorted_vals[hi] * weight)


# --------------------------
# ALGORITMO PRINCIPAL
# --------------------------

class AttributeStatisticsAlgorithm(QgsProcessingAlgorithm):

    INPUT_LAYER = "INPUT_LAYER"
    EXCLUDE_FIELDS = "EXCLUDE_FIELDS"
    PRECISION = "PRECISION"
    PTBR_FORMAT = "PTBR_FORMAT"
    LOAD_AFTER = "LOAD_AFTER"
    OUTPUT = "OUTPUT"

    def name(self):
        return "attribute_statistics_mtl"

    def displayName(self):
        return "Estatísticas de Atributos (MTL Tools)"

    def group(self):
        return "Estatística"

    def groupId(self):
        return "estatistica"

    def icon(self):
        icon_path = os.path.join(os.path.dirname(__file__), "..", "icons", "attribute_stats.png")
        if os.path.exists(icon_path):
            return QIcon(icon_path)
        return QIcon()

    def createInstance(self):
        return AttributeStatisticsAlgorithm()

    def initAlgorithm(self, config=None):
        prefs = _load_prefs()

        self.addParameter(
            QgsProcessingParameterFeatureSource(
                self.INPUT_LAYER,
                "Camada de entrada (qualquer geometria)",
                [QgsProcessing.TypeVectorAnyGeometry]
            )
        )

        self.addParameter(
            QgsProcessingParameterField(
                self.EXCLUDE_FIELDS,
                "Campos a excluir (opcional)",
                parentLayerParameterName=self.INPUT_LAYER,
                type=QgsProcessingParameterField.Any,
                allowMultiple=True,
                optional=True
            )
        )

        self.addParameter(
            QgsProcessingParameterNumber(
                self.PRECISION,
                "Precisão (casas decimais)",
                type=QgsProcessingParameterNumber.Integer,
                minValue=0,
                maxValue=12,
                defaultValue=prefs["precision"]
            )
        )

        self.addParameter(
            QgsProcessingParameterBoolean(
                self.PTBR_FORMAT,
                "Formato PT-BR (usar ; como separador e , nas casas decimais)",
                defaultValue=prefs["ptbr_format"]
            )
        )

        self.addParameter(
            QgsProcessingParameterBoolean(
                self.LOAD_AFTER,
                "Carregar CSV automaticamente após executar",
                defaultValue=prefs["load_after"]
            )
        )

        self.addParameter(
            QgsProcessingParameterFileDestination(
                self.OUTPUT,
                "Arquivo CSV de saída",
                fileFilter="CSV (*.csv)"
            )
        )

    def shortHelpString(self):
        return (
            "Calcula estatísticas de todos os campos numéricos. "
            "Pode excluir campos manualmente, definir precisão e escolher formato PT-BR."
        )

    # -----------------------------------------------------------------------

    def processAlgorithm(self, parameters, context, feedback):

        prefs_before = _load_prefs()

        source = self.parameterAsSource(parameters, self.INPUT_LAYER, context)
        if source is None:
            raise QgsProcessingException("Camada inválida.")

        exclude_fields = self.parameterAsFields(parameters, self.EXCLUDE_FIELDS, context) or []
        precision = int(self.parameterAsInt(parameters, self.PRECISION, context))
        ptbr_format = bool(self.parameterAsBool(parameters, self.PTBR_FORMAT, context))
        load_after = bool(self.parameterAsBool(parameters, self.LOAD_AFTER, context))
        output_path = self.parameterAsFileOutput(parameters, self.OUTPUT, context)

        feedback.pushInfo(f"[MTL] Precisão: {precision}")
        feedback.pushInfo(f"[MTL] PT-BR: {ptbr_format}")
        feedback.pushInfo(f"[MTL] Excluindo campos: {exclude_fields}")

        # Nome da camada
        try:
            layer_source = source.source()
        except Exception:
            layer_source = ""

        # Extrair campos numéricos
        numeric_fields = []
        for f in source.fields():
            fn = f.name()
            if fn in exclude_fields:
                continue
            t = f.typeName().lower()
            if "int" in t or "float" in t or "real" in t or "double" in t or "numeric" in t:
                numeric_fields.append(fn)

        if not numeric_fields:
            feedback.pushInfo("[MTL] Nenhum campo numérico para processar.")
            return {self.OUTPUT: output_path}

        feedback.pushInfo(f"[MTL] Processando campos: {numeric_fields}")

        values_by_field = {fn: [] for fn in numeric_fields}

        total = source.featureCount()
        for i, feat in enumerate(source.getFeatures()):
            for fn in numeric_fields:
                v = feat[fn]
                if v is None:
                    continue
                try:
                    val = float(v)
                    if math.isfinite(val):
                        values_by_field[fn].append(val)
                except:
                    pass
            if total:
                feedback.setProgress(int((i / total) * 100))

        # CSV - formato PT-BR ou internacional
        sep = ";" if ptbr_format else ","
        dec = "," if ptbr_format else "."

        headers = [
            "Campo",
            "Contagem",
            "Media Absoluta",
            "Media",
            "Desvio Padrao Populacional",
            "Desvio Padrão Amostral",
            "Minimo",
            "Maximo",
            "Amplitude",
            "Mediana",
            "Percentil 5%",
            "Percentil 95%"
        ]

        try:
            with open(output_path, "w", encoding="utf-8") as f:

                f.write(sep.join(headers) + "\n")

                for fn in numeric_fields:
                    vals = sorted(values_by_field[fn])
                    n = len(vals)

                    if n == 0:
                        f.write(sep.join([fn] + [""] * (len(headers) - 1)) + "\n")
                        continue

                    mean_abs = sum(abs(x) for x in vals) / n
                    mean = sum(vals) / n
                    std_pop = math.sqrt(sum((x - mean) ** 2 for x in vals) / n)
                    std_samp = math.sqrt(sum((x - mean) ** 2 for x in vals) / (n - 1)) if n > 1 else float("nan")
                    vmin = vals[0]
                    vmax = vals[-1]
                    vrange = vmax - vmin
                    median = _percentile(vals, 50)
                    p5 = _percentile(vals, 5)
                    p95 = _percentile(vals, 95)

                    def fmt(v):
                        if v is None or (isinstance(v, float) and math.isnan(v)):
                            return ""
                        txt = str(round(v, precision))
                        return txt.replace(".", dec)

                    row = [
                        fn,
                        str(n),
                        fmt(mean_abs), fmt(mean), fmt(std_pop), fmt(std_samp),
                        fmt(vmin), fmt(vmax), fmt(vrange),
                        fmt(median), fmt(p5), fmt(p95)
                    ]

                    f.write(sep.join(row) + "\n")

        except Exception as e:
            raise QgsProcessingException(f"Erro ao salvar CSV: {e}")

        feedback.pushInfo(f"[MTL] Arquivo gerado: {output_path}")

        # Salvar preferências
        _save_prefs(precision, exclude_fields, layer_source, ptbr_format, load_after)

        # Carregar tabela após execução
        if load_after:
            try:
                uri = (
                    f"file:///{output_path}"
                    f"?type=csv&delimiter={sep}&detectTypes=yes&decimalPoint={dec}"
                )

                vl = QgsVectorLayer(uri, os.path.basename(output_path), "delimitedtext")

                if vl.isValid():
                    context.temporaryLayerStore().addMapLayer(vl)
                    feedback.pushInfo("[MTL] CSV carregado no QGIS.")
                else:
                    feedback.pushWarning("[MTL] Falha ao carregar CSV automaticamente (camada inválida).")

            except Exception as e:
                feedback.pushWarning(f"[MTL] Erro ao carregar CSV automaticamente: {e}")

        # Link para pasta
        folder = os.path.dirname(output_path)
        feedback.pushInfo(f"📂 Abra a pasta do arquivo: <a href=\"file:///{folder}\">{folder}</a>")

        return {self.OUTPUT: output_path}

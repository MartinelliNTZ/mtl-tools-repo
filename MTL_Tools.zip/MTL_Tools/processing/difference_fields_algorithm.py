# -*- coding: utf-8 -*-
import os
from PyQt5.QtGui import QIcon
from PyQt5.QtCore import QVariant

from qgis.core import (
    QgsProcessingAlgorithm,
    QgsProcessingParameterFeatureSource,
    QgsProcessingParameterField,
    QgsProcessingParameterString,
    QgsProcessingParameterFeatureSink,
    QgsProcessingParameterNumber,
    QgsProcessing,
    QgsFields, QgsField, QgsFeature, QgsFeatureSink
)

# Preferências
from ..utils.preferences import load_tool_prefs, save_tool_prefs


class DifferenceFieldsAlgorithm(QgsProcessingAlgorithm):

    INPUT_LAYER = "INPUT_LAYER"
    BASE_FIELD = "BASE_FIELD"
    FIELDS_TO_COMPARE = "FIELDS_TO_COMPARE"
    PREFIX = "PREFIX"
    PRECISION = "PRECISION"
    OUTPUT = "OUTPUT"

    TOOL_KEY = "difference_fields_tool"

    # -----------------------------------------------------------
    # Identificação
    # -----------------------------------------------------------
    def name(self):
        return "difference_fields"

    def displayName(self):
        return "Gerador de Diferenças entre Campos"

    def group(self):
        return "Estatística"

    def groupId(self):
        return "estatistica"

    def icon(self):
        icon_path = os.path.join(os.path.dirname(__file__), "..", "icons", "field_diference.png")
        return QIcon(icon_path)

    def createInstance(self):
        return DifferenceFieldsAlgorithm()

    # -----------------------------------------------------------
    # Carregar preferências
    # -----------------------------------------------------------
    def _load_prefs(self):
        prefs = load_tool_prefs(self.TOOL_KEY)
        return {
            "prefix": prefs.get("prefix", "D_"),
            "precision": prefs.get("precision", 4),
        }

    # -----------------------------------------------------------
    # Salvar preferências
    # -----------------------------------------------------------
    def _save_prefs(self, prefix, precision):
        save_tool_prefs(
            self.TOOL_KEY,
            {
                "prefix": prefix,
                "precision": precision,
            }
        )

    # -----------------------------------------------------------
    # Definição dos parâmetros
    # -----------------------------------------------------------
    def initAlgorithm(self, config=None):

        prefs = self._load_prefs()

        self.addParameter(
            QgsProcessingParameterFeatureSource(
                self.INPUT_LAYER,
                "Camada de Pontos",
                [QgsProcessing.TypeVectorPoint]
            )
        )

        self.addParameter(
            QgsProcessingParameterField(
                self.BASE_FIELD,
                "Campo Base (subtraendo)",
                parentLayerParameterName=self.INPUT_LAYER,
                type=QgsProcessingParameterField.Numeric
            )
        )

        self.addParameter(
            QgsProcessingParameterField(
                self.FIELDS_TO_COMPARE,
                "Campos para Comparar (minuendo)",
                parentLayerParameterName=self.INPUT_LAYER,
                type=QgsProcessingParameterField.Numeric,
                allowMultiple=True
            )
        )

        self.addParameter(
            QgsProcessingParameterString(
                self.PREFIX,
                "Prefixo para novos campos",
                defaultValue=prefs["prefix"]
            )
        )

        self.addParameter(
            QgsProcessingParameterNumber(
                self.PRECISION,
                "Precisão (casas decimais)",
                type=QgsProcessingParameterNumber.Integer,
                minValue=0,
                maxValue=10,
                defaultValue=prefs["precision"]
            )
        )

        self.addParameter(
            QgsProcessingParameterFeatureSink(
                self.OUTPUT,
                "Diferenca"
            )
        )

    # -----------------------------------------------------------
    # PROCESSAMENTO
    # -----------------------------------------------------------
    def processAlgorithm(self, params, context, feedback):

        layer = self.parameterAsSource(params, self.INPUT_LAYER, context)
        base_field = self.parameterAsFields(params, self.BASE_FIELD, context)[0]
        fields_to_compare = self.parameterAsFields(params, self.FIELDS_TO_COMPARE, context)
        prefix = self.parameterAsString(params, self.PREFIX, context)
        precision = self.parameterAsInt(params, self.PRECISION, context)

        # Logs
        feedback.pushInfo(f"Base: {base_field}")
        feedback.pushInfo(f"Campos escolhidos: {fields_to_compare}")
        feedback.pushInfo(f"Prefixo: {prefix}")
        feedback.pushInfo(f"Precisão: {precision}")

        # Salvar preferências desta execução
        self._save_prefs(prefix, precision)

        # -----------------------------------------------------------
        # Criar novos campos
        # -----------------------------------------------------------
        out_fields = QgsFields()
        for f in layer.fields():
            out_fields.append(f)

        for col in fields_to_compare:
            new_name = f"{prefix}{col}"
            out_fields.append(QgsField(new_name, QVariant.Double))

        sink, dest = self.parameterAsSink(
            params, self.OUTPUT, context,
            out_fields, layer.wkbType(), layer.sourceCrs()
        )

        # -----------------------------------------------------------
        # Loop dos pontos
        # -----------------------------------------------------------
        for feat in layer.getFeatures():

            geom = feat.geometry()
            attrs = feat.attributes()
            base_value = feat[base_field]

            out_feat = QgsFeature(out_fields)
            out_feat.setGeometry(geom)

            for col in fields_to_compare:
                value = feat[col]

                if value is None or base_value is None:
                    attrs.append(None)
                else:
                    diff = float(value) - float(base_value)
                    attrs.append(round(diff, precision))

            out_feat.setAttributes(attrs)
            sink.addFeature(out_feat, QgsFeatureSink.FastInsert)

        feedback.pushInfo("✔ Processo finalizado com sucesso.")

        return {self.OUTPUT: dest}

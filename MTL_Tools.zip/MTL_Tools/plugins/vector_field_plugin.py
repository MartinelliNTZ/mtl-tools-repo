# -*- coding: utf-8 -*-
from qgis.PyQt.QtWidgets import QAction
from qgis.core import QgsVectorLayer, QgsWkbTypes, QgsApplication
import os

from ..model.vector_field_calculator import VectorFieldCalculator
from ..utils.altimetry_task import AltimetriaTask
from ..utils.qgis_messagem_util import QgisMessageUtil
from ..utils.crs_utils import get_coord_info


class VectorFieldPlugin:

    def __init__(self, iface):
        self.iface = iface
        self.actions = []

    def initGui(self):
        icon_path = os.path.join(
            os.path.dirname(__file__), "../icons/vector_field.png"
        )
        action = QAction(icon_path, "Calcular Campos Vetoriais", self.iface.mainWindow())
        action.triggered.connect(self.run_vector_field)
        self.iface.addPluginToMenu("MTL Tools", action)
        self.actions.append(action)

    def unload(self):
        for a in self.actions:
            self.iface.removePluginMenu("MTL Tools", a)

    # --------------------------------------------------
    # CONTROLLER
    # --------------------------------------------------
    def run_vector_field(self):
        layer = self.iface.activeLayer()

        if not layer or not isinstance(layer, QgsVectorLayer):
            QgisMessageUtil.bar_critical(self.iface, "Selecione uma camada vetorial")
            return

        if not layer.isEditable():
            QgisMessageUtil.bar_critical(self.iface, "A camada precisa estar em edição")
            return

        calc = VectorFieldCalculator(layer)
        geom_type = layer.geometryType()

        if geom_type == QgsWkbTypes.PointGeometry:
            self._run_point_fields(layer, calc)

        elif geom_type == QgsWkbTypes.LineGeometry:
            self._run_line_fields(layer, calc)

        elif geom_type == QgsWkbTypes.PolygonGeometry:
            self._run_polygon_fields(layer, calc)

        else:
            QgisMessageUtil.bar_warning(
                self.iface,
                "Tipo de geometria não suportado"
            )

    def _run_polygon_fields(self, layer, calc):
        field = "area"

        if layer.fields().lookupField(field) != -1:
            action = QgisMessageUtil.ask_field_conflict(self.iface, field)

            if action == "cancel":
                return
            elif action == "rename":
                i = 1
                while layer.fields().lookupField(f"{field}_{i}") != -1:
                    i += 1
                field = f"{field}_{i}"
            # replace → mantém "area"

        calc.calculate_polygon_area(field)
        QgisMessageUtil.bar_success(self.iface, "Área calculada")
        
    def _run_line_fields(self, layer, calc):
        field = "length"

        if layer.fields().lookupField(field) != -1:
            action = QgisMessageUtil.ask_field_conflict(self.iface, field)

            if action == "cancel":
                return
            elif action == "rename":
                i = 1
                while layer.fields().lookupField(f"{field}_{i}") != -1:
                    i += 1
                field = f"{field}_{i}"
            # replace → mantém "length"

        calc.calculate_line_length(field)
        QgisMessageUtil.bar_success(self.iface, "Comprimento calculado")
        
    def _run_point_fields(self, layer, calc):
        include_z = QgisMessageUtil.confirm(
            self.iface,
            "Deseja adicionar Z (Altimetria)?"
        )

        # -------- decisão de campos --------
        field_map = {}
        for base in ["x", "y"] + (["z"] if include_z else []):
            if layer.fields().lookupField(base) != -1:
                action = QgisMessageUtil.ask_field_conflict(self.iface, base)

                if action == "cancel":
                    return

                if action == "replace":
                    field_map[base] = base

                elif action == "rename":
                    i = 1
                    while layer.fields().lookupField(f"{base}_{i}") != -1:
                        i += 1
                    field_map[base] = f"{base}_{i}"
            else:
                field_map[base] = base

        calc.create_point_fields(field_map)
        calc.update_point_xy(field_map)

        # -------- Z com TASK --------
        if not include_z:
            QgisMessageUtil.bar_success(self.iface, "Campos X/Y calculados")
            return

        total = layer.featureCount()
        if total > 5000:
            QgisMessageUtil.bar_warning(
                self.iface,
                "Mais de 5000 feições: Z ignorado"
            )
            return

        z_results = {}
        pending = total

        def make_callback(fid):
            def cb(value, error):
                nonlocal pending
                if not error:
                    z_results[fid] = round(value, 8)
                pending -= 1

                if pending == 0:
                    calc.update_point_z(z_results, field_map["z"])
                    QgisMessageUtil.bar_success(
                        self.iface,
                        "X, Y e Z calculados com sucesso"
                    )
            return cb

        for feat in layer.getFeatures():
            p = feat.geometry().asPoint()
            info = get_coord_info(p, layer.crs())

            task = AltimetriaTask(
                info["lat"],
                info["lon"],
                make_callback(feat.id())
            )
            QgsApplication.taskManager().addTask(task)



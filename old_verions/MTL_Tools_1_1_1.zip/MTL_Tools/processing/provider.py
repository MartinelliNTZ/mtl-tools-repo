# -*- coding: utf-8 -*-
from qgis.core import QgsProcessingProvider
from .my_algorithm import MTLExampleAlgorithm

#from .export_all_layouts import ExportAllLayoutsDialog   
#from .replace_in_layouts import ReplaceInLayoutsDialog
#from .restart_qgis import run_restart_qgis




class MTLProvider(QgsProcessingProvider):

    def loadAlgorithms(self):
        """Register all algorithms here."""
      #  self.addAlgorithm(ExportAllLayoutsDialog())
      #  self.addAlgorithm(ReplaceInLayoutsDialog())


        


    def id(self):
        return "mtl_tools"

    def name(self):
        return "MTL Tools"

    def longName(self):
        return "MTL Tools – Processamento"

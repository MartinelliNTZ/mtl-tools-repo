# raster_sampler_logic.py
# -*- coding: utf-8 -*-
from qgis.core import QgsFields, QgsField, QgsFeature, QgsCoordinateTransform, QgsFeatureSink
from qgis.PyQt.QtCore import QVariant

class RasterMassSamplerLogic:
    """
    Classe responsável pelo processamento da amostragem de rasters.
    Reutilizável por múltiplas ferramentas.
    """
    
    def __init__(self, points_layer, rasters, context):
        self.points_layer = points_layer
        self.rasters = rasters
        self.context = context
    
    def sample_rasters(self, out_fields, wkb_type, crs, sink):
        """
        Executa a amostragem dos rasters nos pontos.
        out_fields: QgsFields já contendo os campos originais + campos de raster
        sink: QgsFeatureSink para gravar os resultados
        """
        # CRS transforms para cada raster
        transforms = [
            QgsCoordinateTransform(self.points_layer.sourceCrs(), ras.crs(), self.context.transformContext())
            for ras in self.rasters
        ]

        raster_names = [ras.name()[:10] for ras in self.rasters]

        for feat in self.points_layer.getFeatures():
            geom = feat.geometry()
            if geom is None:
                continue

            out_feat = QgsFeature(out_fields)
            out_feat.setGeometry(geom)
            attrs = feat.attributes()

            for i, ras in enumerate(self.rasters):
                pt = transforms[i].transform(geom.asPoint())
                val = ras.dataProvider().sample(pt, 1)[0]
                attrs.append(float(val) if val is not None else None)

            out_feat.setAttributes(attrs)
            sink.addFeature(out_feat, QgsFeatureSink.FastInsert)
        
        return raster_names

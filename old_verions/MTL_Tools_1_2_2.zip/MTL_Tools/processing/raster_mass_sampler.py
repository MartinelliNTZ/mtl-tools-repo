# -*- coding: utf-8 -*-
import os
from PyQt5.QtGui import QIcon
from qgis.core import (
    QgsProcessingAlgorithm,
    QgsProcessingParameterFeatureSource,
    QgsProcessingParameterMultipleLayers,
    QgsProcessingParameterFeatureSink,
    QgsFields, QgsField, QgsFeature, QgsFeatureSink,
    QgsCoordinateTransform
)
from qgis.core import QgsProcessing

from PyQt5.QtCore import QVariant

class RasterMassSampler(QgsProcessingAlgorithm):

    INPUT_POINTS = "INPUT_POINTS"
    INPUT_RASTERS = "INPUT_RASTERS"
    OUTPUT = "OUTPUT"

    # --------------------------
    # MÉTODOS OBRIGATÓRIOS
    # --------------------------
    def name(self):
        return "raster_mass_sampler"

    def displayName(self):
        return "Amostragem Massiva de Rasters"

    def createInstance(self):
        print("[DEBUG] createInstance chamado para RasterMassSampler")
        return RasterMassSampler()

    # --------------------------
    # ALGORITMO
    # --------------------------
    def initAlgorithm(self, config=None):

        print("[DEBUG] initAlgorithm chamado")

        self.addParameter(
            QgsProcessingParameterFeatureSource(
                self.INPUT_POINTS,
                "Pontos de entrada",
                [QgsProcessing.TypeVectorPoint]
            )
        )

        self.addParameter(
            QgsProcessingParameterMultipleLayers(
                self.INPUT_RASTERS,
                "Rasters",
                QgsProcessing.TypeRaster
            )
        )

        self.addParameter(
            QgsProcessingParameterFeatureSink(
                self.OUTPUT,
                "Valores_Amostrados"
            )
        )

    def processAlgorithm(self, params, context, feedback):

        print("[DEBUG] processAlgorithm iniciado")

        pts = self.parameterAsSource(params, self.INPUT_POINTS, context)
        rasters = self.parameterAsLayerList(params, self.INPUT_RASTERS, context)

        print(f"[DEBUG] Pontos: {pts}")
        print(f"[DEBUG] Total de rasters: {len(rasters)}")

        # Criar campos
        out_fields = QgsFields()
        for f in pts.fields():
            out_fields.append(f)

        raster_fields = []
        for ras in rasters:
            name = ras.name()[:10]
            raster_fields.append(name)
            out_fields.append(QgsField(name, QVariant.Double))

        sink, dest = self.parameterAsSink(
            params, self.OUTPUT, context,
            out_fields, pts.wkbType(), pts.sourceCrs()
        )

        print("[DEBUG] Campos criados:", raster_fields)

        # Transforms CRS
        transforms = []
        for ras in rasters:
            transforms.append(
                QgsCoordinateTransform(
                    pts.sourceCrs(),
                    ras.crs(),
                    context.transformContext()
                )
            )

        # Loop dos pontos
        for feat in pts.getFeatures():

            geom = feat.geometry()
            if geom is None:
                continue

            out_feat = QgsFeature(out_fields)
            out_feat.setGeometry(geom)
            attrs = feat.attributes()

            for i, ras in enumerate(rasters):
                pt = transforms[i].transform(geom.asPoint())
                val = ras.dataProvider().sample(pt, 1)[0]

                print(f"[DEBUG] Ponto {feat.id()}, Raster {ras.name()} = {val}")

                attrs.append(float(val) if val is not None else None)

            out_feat.setAttributes(attrs)
            sink.addFeature(out_feat, QgsFeatureSink.FastInsert)

        print("[DEBUG] Finalizado processamento.")

        return {self.OUTPUT: dest}
    
    def icon(self):
        path = os.path.join(os.path.dirname(__file__), "..", "icons", "raster_mass.png")
        return QIcon(path)
    def group(self):
        return "Estatistica"

    def groupId(self):
        return "estatistica"
# -*- coding: utf-8 -*-
import os
from qgis.PyQt.QtWidgets import QAction, QMenu
from qgis.PyQt.QtGui import QIcon
from qgis.core import QgsApplication

from .processing.provider import MTLProvider


class MTL_Tools:
    def __init__(self, iface):
        self.iface = iface
        self.menu = None
        self.toolbar = None
        self.actions = []
        self.provider = None

    # =====================================================
    # INICIAR GUI E PROCESSING
    # =====================================================
    def initGui(self):

        # -------------------------
        # 1) ATIVAR PROCESSING PROVIDER
        # -------------------------
        self.provider = MTLProvider()
        QgsApplication.processingRegistry().addProvider(self.provider)

        # -------------------------
        # 2) CRIAR TOOLBAR EXCLUSIVA
        # -------------------------
        self.toolbar = self.iface.addToolBar("MTL Tools")
        self.toolbar.setObjectName("MTL_Tools_Toolbar")

        # -------------------------
        # 3) MENU PRINCIPAL
        # -------------------------
        self.menu = QMenu("MTL Tools", self.iface.mainWindow())

        # =====================================================
        # FERRAMENTA 1 – Export All Layouts
        # =====================================================
        export_icon = os.path.join(os.path.dirname(__file__), "icons", "export_icon.png")

        self.action_export_all = QAction(
            QIcon(export_icon),
            "Exportar todos os Layouts",
            self.iface.mainWindow()
        )
        self.action_export_all.triggered.connect(self.run_export_layouts)

        self.menu.addAction(self.action_export_all)
        self.iface.addPluginToMenu("MTL Tools", self.action_export_all)
        self.toolbar.addAction(self.action_export_all)
        self.actions.append(self.action_export_all)

        # =====================================================
        # FERRAMENTA 2 – Replace in Layouts
        # =====================================================
        replace_icon = os.path.join(os.path.dirname(__file__), "icons", "replace_in_layouts.png")

        self.action_replace_layouts = QAction(
            QIcon(replace_icon),
            "Substituir textos nos Layouts",
            self.iface.mainWindow()
        )
        self.action_replace_layouts.triggered.connect(self.run_replace_layouts)

        self.menu.addAction(self.action_replace_layouts)
        self.iface.addPluginToMenu("MTL Tools", self.action_replace_layouts)
        #self.toolbar.addAction(self.action_replace_layouts)
        self.actions.append(self.action_replace_layouts)

        # =====================================================
        # FERRAMENTA 3 – Restart QGIS
        # =====================================================
        restart_icon = os.path.join(os.path.dirname(__file__), "icons", "restart_qgis.png")

        self.action_restart_qgis = QAction(
            QIcon(restart_icon),
            "Salvar, Fechar e Reabrir Projeto",
            self.iface.mainWindow()
        )
        self.action_restart_qgis.triggered.connect(self.run_restart_qgis)

        self.menu.addAction(self.action_restart_qgis)
        self.iface.addPluginToMenu("MTL Tools", self.action_restart_qgis)
        self.toolbar.addAction(self.action_restart_qgis)
        self.actions.append(self.action_restart_qgis)

    # =====================================================
    # DESCARREGAR PLUGIN
    # =====================================================
    def unload(self):

        # Remover provider do Processing
        if self.provider:
            QgsApplication.processingRegistry().removeProvider(self.provider)

        # Remover ações do menu e toolbar
        for act in self.actions:
            self.iface.removePluginMenu("MTL Tools", act)
            self.iface.removeToolBarIcon(act)

        # Remover toolbar
        if self.toolbar:
            del self.toolbar

    # =====================================================
    # EXECUTAR: Export All Layouts
    # =====================================================
    def run_export_layouts(self):
        from .plugins.export_all_layouts import ExportAllLayoutsDialog
        dlg = ExportAllLayoutsDialog()
        dlg.exec()

    # =====================================================
    # EXECUTAR: Replace Text in Layouts
    # =====================================================
    def run_replace_layouts(self):
        from .plugins.replace_in_layouts import run_replace_in_layouts
        run_replace_in_layouts(self.iface)

    # =====================================================
    # EXECUTAR: Restart QGIS
    # =====================================================
    def run_restart_qgis(self):
        from .plugins.restart_qgis import run_restart_qgis
        run_restart_qgis(self.iface)

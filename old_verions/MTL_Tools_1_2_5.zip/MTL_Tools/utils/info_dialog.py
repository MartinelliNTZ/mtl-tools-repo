import os

from qgis.PyQt.QtWidgets import (
    QDialog, QVBoxLayout, QPushButton, QTextEdit
)

from qgis.PyQt.QtCore import  Qt


# ============================================================
#  ** Janela de Informações (MESMA DO OUTRO PLUGIN) **
# ============================================================
class InfoDialog(QDialog):
    def __init__(self, instructions_path: str, parent=None, title="MTL Tools"):
        super().__init__(parent)
        self.setWindowTitle(title)
        self.setMinimumWidth(650)
        self.setMinimumHeight(500)

        layout = QVBoxLayout()

        txt = QTextEdit()
        txt.setReadOnly(True)

        if os.path.exists(instructions_path):
            with open(instructions_path, "r", encoding="utf-8") as f:
                txt.setPlainText(f.read())
        else:
            txt.setPlainText("Arquivo de instruções não encontrado:\n" + instructions_path)

        layout.addWidget(txt)

        btn = QPushButton("Fechar")
        btn.clicked.connect(self.close)
        layout.addWidget(btn, alignment=Qt.AlignRight)

        self.setLayout(layout)   
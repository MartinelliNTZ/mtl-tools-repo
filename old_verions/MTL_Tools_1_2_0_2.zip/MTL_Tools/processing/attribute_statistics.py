# -*- coding: utf-8 -*-
import os
import math
import statistics
from datetime import datetime

from qgis.PyQt.QtGui import QIcon
from qgis.PyQt.QtCore import QVariant

from qgis.core import (
    QgsProcessingAlgorithm,
    QgsProcessingParameterFeatureSource,
    QgsProcessingParameterField,
    QgsProcessingParameterString,
    QgsProcessingParameterFileDestination,
    QgsProcessingParameterNumber,
    QgsProcessingParameterBoolean,
    QgsProcessing,
    QgsFields,
    QgsField,
    QgsFeature,
    QgsFeatureSink,
    QgsWkbTypes,
    QgsProcessingException,
    QgsVectorLayer,
    QgsProcessingParameterDefinition
)

# Preferências
from ..utils.preferences import load_tool_prefs, save_tool_prefs

TOOL_KEY = "attribute_stats_tool"


# --------------------------------------------------------------------------------------
# CARREGAR / SALVAR PREFERÊNCIAS
# --------------------------------------------------------------------------------------
def _load_prefs():
    prefs = load_tool_prefs(TOOL_KEY)
    return {
        "precision": int(prefs.get("precision", 4)),
        "exclude_fields": prefs.get("exclude_fields", []),
        "last_output_folder": prefs.get("last_output_folder", ""),
        "last_layer_source": prefs.get("last_layer_source", ""),
        "ptbr_format": bool(prefs.get("ptbr_format", False)),
        "load_after": bool(prefs.get("load_after", False)),
        "stats_enabled": prefs.get("stats_enabled", {})
    }


def _save_prefs(**kwargs):
    save_tool_prefs(TOOL_KEY, kwargs)


def _percentile(sorted_vals, q):
    if not sorted_vals:
        return float("nan")
    n = len(sorted_vals)
    if n == 1:
        return float(sorted_vals[0])
    pos = (q / 100.0) * (n - 1)
    lo = int(math.floor(pos))
    hi = int(math.ceil(pos))
    if lo == hi:
        return float(sorted_vals[int(pos)])
    weight = pos - lo
    return float(sorted_vals[lo] * (1 - weight) + sorted_vals[hi] * weight)


# --------------------------------------------------------------------------------------
# ALGORITMO
# --------------------------------------------------------------------------------------
class AttributeStatisticsAlgorithm(QgsProcessingAlgorithm):

    INPUT_LAYER = "INPUT_LAYER"
    EXCLUDE_FIELDS = "EXCLUDE_FIELDS"
    PRECISION = "PRECISION"
    PTBR_FORMAT = "PTBR_FORMAT"
    LOAD_AFTER = "LOAD_AFTER"
    OUTPUT = "OUTPUT"

    STATS = {
        "MEAN": "Média",
        "MEAN_ABS": "Média Absoluta",
        "STD_POP": "Desvio Padrão (Pop.)",
        "STD_SAMP": "Desvio Padrão (Amostra)",
        "MIN": "Mínimo",
        "MAX": "Máximo",
        "RANGE": "Amplitude",
        "MEDIAN": "Mediana",
        "P5": "Percentil 5%",
        "P95": "Percentil 95%",
        "MODE": "Moda",
        "VARIANCE": "Variância",
        "SUM": "Soma",
        "CV": "Coeficiente de Variação",
        "SKEW": "Assimetria",
        "KURT": "Curtose"
    }

    def name(self):
        return "attribute_statistics_mtl"

    def displayName(self):
        return "Estatísticas de Atributos (MTL Tools)"

    def group(self):
        return "Estatística"

    def groupId(self):
        return "estatistica"

    def icon(self):
        icon_path = os.path.join(os.path.dirname(__file__), "..", "icons", "attribute_stats.png")
        return QIcon(icon_path) if os.path.exists(icon_path) else QIcon()

    def createInstance(self):
        return AttributeStatisticsAlgorithm()

    # --------------------------------------------------------------------------------------
    # PARÂMETROS
    # --------------------------------------------------------------------------------------
    def initAlgorithm(self, config=None):

        prefs = _load_prefs()

        # Camada de entrada
        self.addParameter(
            QgsProcessingParameterFeatureSource(
                self.INPUT_LAYER,
                "Camada de entrada",
                [QgsProcessing.TypeVectorAnyGeometry]
            )
        )

        # Campos a excluir
        self.addParameter(
            QgsProcessingParameterField(
                self.EXCLUDE_FIELDS,
                "Campos a excluir (opcional)",
                parentLayerParameterName=self.INPUT_LAYER,
                type=QgsProcessingParameterField.Any,
                allowMultiple=True,
                optional=True
            )
        )

        # Precisão
        self.addParameter(
            QgsProcessingParameterNumber(
                self.PRECISION,
                "Precisão (casas decimais)",
                type=QgsProcessingParameterNumber.Integer,
                minValue=0,
                maxValue=12,
                defaultValue=prefs["precision"]
            )
        )

        # ---------- AVANÇADOS ----------

        p_ptbr = QgsProcessingParameterBoolean(
            self.PTBR_FORMAT,
            "Formato PT-BR (usar ; e , )",
            defaultValue=prefs["ptbr_format"]
        )
        p_ptbr.setFlags(p_ptbr.flags() | QgsProcessingParameterDefinition.FlagAdvanced)
        self.addParameter(p_ptbr)

        p_load = QgsProcessingParameterBoolean(
            self.LOAD_AFTER,
            "Carregar CSV automaticamente após execução",
            defaultValue=prefs["load_after"]
        )
        p_load.setFlags(p_load.flags() | QgsProcessingParameterDefinition.FlagAdvanced)
        self.addParameter(p_load)

        # Checkboxes
        enabled_stats = prefs.get("stats_enabled", {})
        for key, label in self.STATS.items():
            p = QgsProcessingParameterBoolean(
                key,
                f"Calcular: {label}",
                defaultValue=enabled_stats.get(key, True)
            )
            p.setFlags(p.flags() | QgsProcessingParameterDefinition.FlagAdvanced)
            self.addParameter(p)

        # -------------------------------------------------------
        # OUTPUT — AGORA COM NOME PADRÃO DO ÚLTIMO ARQUIVO USADO
        # -------------------------------------------------------
        last_folder = prefs.get("last_output_folder", "")
        last_name = "atributos_estatistica.csv"

        if last_folder:
            default_output = os.path.join(last_folder, last_name)
        else:
            default_output = None

        self.addParameter(
            QgsProcessingParameterFileDestination(
                self.OUTPUT,
                "Arquivo CSV de saída",
                fileFilter="CSV (*.csv)",
                defaultValue=default_output
            )
        )

    # --------------------------------------------------------------------------------------
    # PROCESSAMENTO
    # --------------------------------------------------------------------------------------
    def processAlgorithm(self, parameters, context, feedback):

        prefs_before = _load_prefs()

        layer = self.parameterAsLayer(parameters, self.INPUT_LAYER, context)
        if layer is None:
            raise QgsProcessingException("Camada inválida.")

        source = layer

        exclude_fields = self.parameterAsFields(parameters, self.EXCLUDE_FIELDS, context) or []
        precision = int(self.parameterAsInt(parameters, self.PRECISION, context))
        ptbr_format = bool(self.parameterAsBool(parameters, self.PTBR_FORMAT, context))
        load_after = bool(self.parameterAsBool(parameters, self.LOAD_AFTER, context))
        stats_enabled = {k: self.parameterAsBool(parameters, k, context) for k in self.STATS.keys()}

        output_path = self.parameterAsFileOutput(parameters, self.OUTPUT, context)
        out_folder = os.path.dirname(output_path)

        # -----------------------------------------------
        # Extrair campos numéricos
        # -----------------------------------------------
        numeric_fields = []
        for f in source.fields():
            fn = f.name()
            if fn in exclude_fields:
                continue
            t = f.typeName().lower()
            if "int" in t or "float" in t or "real" in t or "double" in t or "numeric" in t:
                numeric_fields.append(fn)

        if not numeric_fields:
            feedback.pushInfo("Nenhum campo numérico encontrado.")
            return {self.OUTPUT: output_path}

        # -----------------------------------------------
        # Coleta valores
        # -----------------------------------------------
        values_by_field = {fn: [] for fn in numeric_fields}
        total = source.featureCount()

        for i, feat in enumerate(source.getFeatures()):
            for fn in numeric_fields:
                v = feat[fn]
                if v is None:
                    continue
                try:
                    val = float(v)
                    if math.isfinite(val):
                        values_by_field[fn].append(val)
                except:
                    pass

            if total:
                feedback.setProgress(int(100 * i / total))

        # -----------------------------------------------
        # Escrita CSV
        # -----------------------------------------------
        sep = ";" if ptbr_format else ","
        dec = "," if ptbr_format else "."

        headers = ["Campo", "Contagem"]
        for key, label in self.STATS.items():
            if stats_enabled.get(key, False):
                headers.append(label)

        def fmt(v):
            if v is None or (isinstance(v, float) and math.isnan(v)):
                return ""
            txt = str(round(v, precision))
            return txt.replace(".", dec)

        try:
            with open(output_path, "w", encoding="utf-8") as f:

                f.write(sep.join(headers) + "\n")

                for fn in numeric_fields:
                    vals = sorted(values_by_field[fn])
                    n = len(vals)

                    row = [fn, str(n)]

                    if n == 0:
                        row += [""] * (len(headers) - 2)
                        f.write(sep.join(row) + "\n")
                        continue

                    if stats_enabled["MEAN_ABS"]:
                        row.append(fmt(sum(abs(x) for x in vals) / n))
                    if stats_enabled["MEAN"]:
                        row.append(fmt(sum(vals) / n))
                    if stats_enabled["STD_POP"]:
                        mean = sum(vals) / n
                        row.append(fmt(math.sqrt(sum((x - mean) ** 2 for x in vals) / n)))
                    if stats_enabled["STD_SAMP"]:
                        mean = sum(vals) / n
                        row.append(fmt(math.sqrt(sum((x - mean) ** 2 for x in vals) / (n - 1))) if n > 1 else "")
                    if stats_enabled["MIN"]:
                        row.append(fmt(vals[0]))
                    if stats_enabled["MAX"]:
                        row.append(fmt(vals[-1]))
                    if stats_enabled["RANGE"]:
                        row.append(fmt(vals[-1] - vals[0]))
                    if stats_enabled["MEDIAN"]:
                        row.append(fmt(_percentile(vals, 50)))
                    if stats_enabled["P5"]:
                        row.append(fmt(_percentile(vals, 5)))
                    if stats_enabled["P95"]:
                        row.append(fmt(_percentile(vals, 95)))
                    if stats_enabled["MODE"]:
                        try:
                            row.append(fmt(statistics.mode(vals)))
                        except:
                            row.append("")
                    if stats_enabled["VARIANCE"]:
                        row.append(fmt(statistics.pvariance(vals)))
                    if stats_enabled["SUM"]:
                        row.append(fmt(sum(vals)))
                    if stats_enabled["CV"]:
                        mean = sum(vals) / n
                        row.append(fmt((statistics.pstdev(vals) / mean) if mean != 0 else ""))
                    if stats_enabled["SKEW"]:
                        mean = sum(vals) / n
                        sd = statistics.pstdev(vals)
                        if sd > 0:
                            skew = sum((x - mean) ** 3 for x in vals) / (n * sd ** 3)
                            row.append(fmt(skew))
                        else:
                            row.append("")
                    if stats_enabled["KURT"]:
                        mean = sum(vals) / n
                        sd = statistics.pstdev(vals)
                        if sd > 0:
                            kurt = sum((x - mean) ** 4 for x in vals) / (n * sd ** 4) - 3
                            row.append(fmt(kurt))
                        else:
                            row.append("")

                    f.write(sep.join(row) + "\n")

        except Exception as e:
            raise QgsProcessingException(f"Erro ao salvar CSV: {e}")

        # Salvar preferências
        _save_prefs(
            precision=precision,
            exclude_fields=exclude_fields,
            last_output_folder=out_folder,
            last_layer_source=source.source(),
            ptbr_format=ptbr_format,
            load_after=load_after,
            stats_enabled=stats_enabled
        )

        # Carregar CSV automaticamente
        if load_after:
            uri = (
                f"file:///{output_path}"
                f"?type=csv&delimiter={sep}&detectTypes=yes&decimalPoint={dec}"
            )
            vl = QgsVectorLayer(uri, os.path.basename(output_path), "delimitedtext")
            if vl.isValid():
                context.temporaryLayerStore().addMapLayer(vl)

        return {self.OUTPUT: output_path}

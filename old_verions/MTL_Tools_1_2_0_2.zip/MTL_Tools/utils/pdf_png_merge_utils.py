import os
from PIL import Image
from PyPDF2 import PdfMerger

# -------------------------------------------------------
# UNIR VÁRIOS PDFs EM UM ÚNICO
# -------------------------------------------------------
def merge_pdfs(pdf_list, output_pdf):
    if not pdf_list:
        return False

    merger = PdfMerger()

    for pdf in pdf_list:
        if os.path.exists(pdf):
            merger.append(pdf)

    os.makedirs(os.path.dirname(output_pdf), exist_ok=True)
    merger.write(output_pdf)
    merger.close()
    return True


# -------------------------------------------------------
# UNIR PNGs EM UM PDF (com redimensionamento opcional)
# -------------------------------------------------------
def merge_pngs_to_pdf(png_list, output_pdf, max_width=3500):
    if not png_list:
        return False

    pil_images = []

    for path in png_list:
        if not os.path.exists(path):
            continue

        img = Image.open(path).convert("RGB")
        w, h = img.size

        if w > max_width:
            ratio = max_width / float(w)
            new_h = int(h * ratio)
            img = img.resize((max_width, new_h), Image.LANCZOS)

        pil_images.append(img)

    if not pil_images:
        return False

    first, rest = pil_images[0], pil_images[1:]

    os.makedirs(os.path.dirname(output_pdf), exist_ok=True)
    first.save(output_pdf, save_all=True, append_images=rest)

    return True

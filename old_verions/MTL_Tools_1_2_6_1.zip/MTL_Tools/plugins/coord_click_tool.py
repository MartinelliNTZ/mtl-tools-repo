from qgis.gui import QgsMapTool
from qgis.core import QgsPointXY, QgsPointLocator
from qgis.core import QgsApplication
from ..utils.altimetry_task import AltimetriaTask
from ..utils.crs_utils import get_coord_info
from ..dialogs.coord_result_dialog import CoordResultDialog

class CoordClickTool(QgsMapTool):

    def __init__(self, iface):
        self.iface = iface
        self.canvas = iface.mapCanvas()
        self.alt_task = None  # 👈 referência viva
        super().__init__(self.canvas)

    def canvasReleaseEvent(self, event):
        snap_match = self.canvas.snappingUtils().snapToMap(event.pos())

        if snap_match.isValid():
            point = snap_match.point()
        else:
            point = self.toMapCoordinates(event.pos())

        crs_canvas = self.canvas.mapSettings().destinationCrs()
        info = get_coord_info(point, crs_canvas)

        dlg = CoordResultDialog(self.iface, info)
        dlg.show()

        lat = info["lat"]
        lon = info["lon"]

        def update_altitude(value, error):
            if error:
                dlg.set_altitude(None)
            else:
                dlg.set_altitude(value)

        # ❗ MANTER REFERÊNCIA
        self.alt_task = AltimetriaTask(lat, lon, update_altitude)
        QgsApplication.taskManager().addTask(self.alt_task)


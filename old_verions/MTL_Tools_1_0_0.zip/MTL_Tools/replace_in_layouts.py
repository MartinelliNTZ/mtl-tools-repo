# -*- coding: utf-8 -*-
import os
import re
import shutil
from datetime import datetime
from pathlib import Path

from qgis.core import QgsProject, QgsLayoutItemLabel
from qgis.PyQt.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
    QLineEdit, QMessageBox, QCheckBox, QFileDialog
)
from qgis.PyQt.QtGui import QIcon
from qgis.PyQt.QtCore import QUrl, Qt
from qgis.PyQt.QtGui import QDesktopServices


class ReplaceInLayoutsDialog(QDialog):
    """
    Dialog para realizar substituições em rótulos (QgsLayoutItemLabel) em todos os layouts.
    Integração pensada para ser chamada a partir do plugin MTL Tools.
    """

    def __init__(self, iface):
        super().__init__(iface.mainWindow())
        self.iface = iface
        self.setWindowTitle("MTL Tools — Replace Text in Layouts")
        self.setMinimumWidth(520)

        # Ícone do plugin (opcional: coloque icons/mtl_tools_icon.png no plugin)
        icon_path = os.path.join(os.path.dirname(__file__), "icons", "mtl_tools_icon.png")
        if os.path.exists(icon_path):
            self.setWindowIcon(QIcon(icon_path))

        # Layout principal
        main = QVBoxLayout()

        # Campo para texto a buscar
        h1 = QHBoxLayout()
        h1.addWidget(QLabel("Texto a buscar:"))
        self.txt_old = QLineEdit()
        h1.addWidget(self.txt_old)
        main.addLayout(h1)

        # Campo para texto de substituição
        h2 = QHBoxLayout()
        h2.addWidget(QLabel("Texto a substituir (novo):"))
        self.txt_new = QLineEdit()
        h2.addWidget(self.txt_new)
        main.addLayout(h2)

        # Opções
        self.chk_case_sensitive = QCheckBox("Diferenciar maiúsculas/minúsculas (case sensitive)")
        self.chk_case_sensitive.setChecked(True)
        main.addWidget(self.chk_case_sensitive)

        # Aviso sobre backup (sempre criado)
        lbl_backup = QLabel(
            "<b>Backup:</b> Antes de modificar, será criada uma cópia do projeto (.qgz) "
            "na pasta <i>backup</i> ao lado do arquivo do projeto (se o projeto estiver salvo)."
        )
        lbl_backup.setWordWrap(True)
        main.addWidget(lbl_backup)

        # Botões escolher projeto atual (apenas para mostrar caminho) e executar
        h_buttons = QHBoxLayout()
        self.btn_show_proj = QPushButton("Mostrar arquivo do projeto")
        self.btn_show_proj.clicked.connect(self.show_project_file)
        h_buttons.addWidget(self.btn_show_proj)

        self.btn_run = QPushButton("Executar substituição")
        self.btn_run.clicked.connect(self.on_run_clicked)
        h_buttons.addWidget(self.btn_run)

        main.addLayout(h_buttons)

        # Botões cancelar / fechar
        h_close = QHBoxLayout()
        h_close.addStretch()
        btn_close = QPushButton("Fechar")
        btn_close.clicked.connect(self.close)
        h_close.addWidget(btn_close)
        main.addLayout(h_close)

        self.setLayout(main)

    # --------------------------
    def show_project_file(self):
        """Mostra caminho do arquivo do projeto atual (se existir)."""
        proj = QgsProject.instance()
        fname = proj.fileName()
        if not fname:
            QMessageBox.information(self, "Projeto não salvo", "O projeto atual ainda não foi salvo em disco.")
            return
        QMessageBox.information(self, "Arquivo do Projeto", f"Arquivo atual:\n{fname}")

    # --------------------------
    def on_run_clicked(self):
        old_text = self.txt_old.text()
        new_text = self.txt_new.text()
        case_sensitive = self.chk_case_sensitive.isChecked()

        if not old_text:
            QMessageBox.warning(self, "Erro", "Informe o texto a buscar (texto antigo).")
            return

        # Mensagem de confirmação com alerta vermelho
        confirm = QMessageBox(self)
        confirm.setWindowTitle("Confirme substituições")
        confirm.setIcon(QMessageBox.Warning)
        confirm.setTextFormat(Qt.RichText)
        confirm.setText(
            "<b style='color:red'>Atenção — operação irreversível sem backup</b><br><br>"
            "<b>Texto a buscar:</b> <i>{}</i><br>"
            "<b>Texto de substituição:</b> <i>{}</i><br><br>"
            "Deseja prosseguir? Recomenda-se verificar o backup gerado após a operação."
            .format(self._escape_html(old_text), self._escape_html(new_text))
        )
        confirm.setStandardButtons(QMessageBox.Yes | QMessageBox.No)
        resp = confirm.exec()

        if resp != QMessageBox.Yes:
            return

        # Executa fluxo: backup -> aplicar substituições -> gerar log -> mostrar resultado
        try:
            result = self._perform_replacement(old_text, new_text, case_sensitive)
            # result = dict with keys: sucesso_count, detalhes, backup_folder, log_path
            self._show_result_dialog(result)
        except Exception as e:
            QMessageBox.critical(self, "Erro inesperado", f"Ocorreu um erro:\n{e}")

    # --------------------------
    def _escape_html(self, text: str) -> str:
        return (
            text.replace("&", "&amp;")
            .replace("<", "&lt;")
            .replace(">", "&gt;")
            .replace('"', "&quot;")
            .replace("'", "&#39;")
        )

    # --------------------------
    def _perform_replacement(self, old_text, new_text, case_sensitive):
        """
        Faz o backup do .qgz (se houver), percorre layouts e substitui textos em QgsLayoutItemLabel.
        Retorna um dicionário com resultados.
        """
        project = QgsProject.instance()
        project_file = project.fileName()  # caminho absoluto do .qgz se salvo, else ''

        # Se projeto não salvo -> perguntar se quer prosseguir sem salvar
        if not project_file:
            ask = QMessageBox(self)
            ask.setWindowTitle("Projeto não salvo")
            ask.setIcon(QMessageBox.Warning)
            ask.setText("O projeto atual ainda não está salvo em disco.\n"
                        "Sem um arquivo .qgz não é possível criar backup automático.\n\n"
                        "Deseja prosseguir sem criar backup e aplicar as alterações somente na sessão atual?")
            ask.setStandardButtons(QMessageBox.Yes | QMessageBox.No)
            ans = ask.exec()
            if ans != QMessageBox.Yes:
                raise Exception("Operação cancelada pelo usuário (projeto não salvo).")
            # define project_file_dir for possible log location (use homePath or temp)
            project_dir = project.homePath() or os.path.expanduser("~")
            backup_folder = os.path.join(project_dir, "backup")
            os.makedirs(backup_folder, exist_ok=True)
            backup_file_path = None
        else:
            project_path = Path(project_file)
            project_dir = str(project_path.parent)
            # cria pasta backup
            backup_folder = os.path.join(project_dir, "backup")
            os.makedirs(backup_folder, exist_ok=True)

            # timestamp AAAAMMDDhhmmss
            ts = datetime.now().strftime("%Y%m%d%H%M%S")

            # constrói nome seguro para windows - limita comprimento do base name
            base_name = project_path.stem
            # windows max filename common safe limit (keep conservative)
            max_base_len = 100
            if len(base_name) > max_base_len:
                base_name = base_name[:max_base_len]

            backup_name = f"{base_name}_{ts}{project_path.suffix}"
            backup_file_path = os.path.join(backup_folder, backup_name)

            # copia arquivo com metadados
            shutil.copy2(project_file, backup_file_path)

        # Prepare log
        log_ts = datetime.now().strftime("%Y%m%d%H%M%S")
        log_name = f"replace_log_{log_ts}.txt"
        log_path = os.path.join(backup_folder, log_name)
        log_lines = []
        log_lines.append(f"ReplaceInLayouts log - {datetime.now().isoformat()}")
        log_lines.append(f"Project file: {project_file or 'N/A (projeto não salvo)'}")
        if backup_file_path:
            log_lines.append(f"Backup created: {backup_file_path}")
        else:
            log_lines.append("Backup: N/A (projeto não salvo)")

        # Start processing layouts
        layouts = project.layoutManager().layouts()
        total_layouts = len(layouts)
        log_lines.append(f"Layouts found: {total_layouts}")
        log_lines.append("---- Changes ----")
        changes_count = 0
        details = []

        # Prepare matching depending case sensitivity
        if case_sensitive:
            def match_and_replace(text):
                return text.replace(old_text, new_text) if old_text in text else None
        else:
            low_old = old_text.lower()

            def match_and_replace(text):
                if low_old in text.lower():
                    # do a case-insensitive replace preserving original other chars: simple approach:
                    # replace occurrences by scanning
                    import re as _re
                    pattern = _re.compile(re.escape(old_text), _re.IGNORECASE)
                    return pattern.sub(new_text, text)
                return None

        for layout in layouts:
            layout_name = layout.name()
            layout_changes = []
            for item in layout.items():
                if isinstance(item, QgsLayoutItemLabel):
                    original = item.text()
                    replaced = match_and_replace(original)
                    if replaced is not None and replaced != original:
                        # record BEFORE and AFTER
                        layout_changes.append((original, replaced, getattr(item, 'id', None)))
                        # apply change
                        item.setText(replaced)
                        changes_count += 1

            if layout_changes:
                log_lines.append(f"Layout: {layout_name}")
                for before, after, item_id in layout_changes:
                    safe_item_id = item_id if item_id is not None else "N/A"
                    log_lines.append(f" - Item {safe_item_id}:")
                    log_lines.append(f"    Antes: {before}")
                    log_lines.append(f"    Depois: {after}")
                log_lines.append("")  # blank line

        log_lines.append("---- End of changes ----")
        log_lines.append(f"Total substitutions applied: {changes_count}")
        log_lines.append(f"Operation finished at: {datetime.now().isoformat()}")
        # write log
        with open(log_path, "w", encoding="utf-8") as f:
            f.write("\n".join(log_lines))

        # Return summary
        return {
            "sucesso_count": changes_count,
            "backup_folder": backup_folder,
            "backup_file": backup_file_path,
            "log_path": log_path,
            "details": log_lines,
            "total_layouts": total_layouts
        }

    # --------------------------
    def _show_result_dialog(self, result: dict):
        """Mostra caixa com resultado e opções abrir pasta / abrir log."""
        sucesso = result.get("sucesso_count", 0)
        backup_folder = result.get("backup_folder")
        log_path = result.get("log_path")

        msg = QMessageBox(self)
        msg.setWindowTitle("Substituição concluída")
        msg.setIcon(QMessageBox.Information)
        msg.setTextFormat(Qt.RichText)

        pretty = (
            f"<b>Substituições aplicadas:</b> {sucesso}<br>"
            f"<b>Pasta de backup:</b> {self._escape_html(backup_folder)}<br>"
            f"<b>Arquivo de log:</b> {os.path.basename(log_path)}<br><br>"
            "Você pode abrir a pasta de backup ou visualizar o log."
        )
        msg.setText(pretty)

        # Botões personalizados
        btn_open_folder = msg.addButton("Abrir pasta de backup", QMessageBox.ActionRole)
        btn_open_log = msg.addButton("Abrir log", QMessageBox.ActionRole)
        btn_ok = msg.addButton(QMessageBox.Ok)

        msg.exec()

        clicked = msg.clickedButton()
        if clicked == btn_open_folder:
            QDesktopServices.openUrl(QUrl.fromLocalFile(backup_folder))
        elif clicked == btn_open_log:
            # tenta abrir arquivo de log com o aplicativo padrão
            QDesktopServices.openUrl(QUrl.fromLocalFile(log_path))
        # se OK, apenas fecha

# --------------------------
# Helper: função que plugin pode chamar
def run_replace_in_layouts(iface):
    """
    Função de entrada para o plugin: cria o diálogo e executa.
    No seu arquivo principal do plugin (MTL_Tools.py) chame:
        from .replace_in_layouts import run_replace_in_layouts
        run_replace_in_layouts(self.iface)
    """
    dlg = ReplaceInLayoutsDialog(iface)
    dlg.exec()

# Fim do arquivo

import os
import re

from qgis.core import QgsProject, QgsLayoutExporter
from qgis.PyQt.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
    QCheckBox, QFileDialog, QLineEdit, QMessageBox
)
from qgis.PyQt.QtCore import QUrl, Qt
from qgis.PyQt.QtGui import QIcon


class ExportAllLayoutsDialog(QDialog):

    def __init__(self):
        super().__init__()

        self.setWindowTitle("Export All Layouts – MTL Tools")
        self.setMinimumWidth(420)

        # Ícone da janela
        icon_path = os.path.join(os.path.dirname(__file__), "icons", "export_icon.png")
        if os.path.exists(icon_path):
            self.setWindowIcon(QIcon(icon_path))

        layout = QVBoxLayout()

        # === OPÇÕES DE FORMATO ===
        self.chk_pdf = QCheckBox("Exportar PDF")
        self.chk_pdf.setChecked(True)

        self.chk_png = QCheckBox("Exportar PNG")
        self.chk_png.setChecked(True)

        layout.addWidget(self.chk_pdf)
        layout.addWidget(self.chk_png)

        # === OPÇÃO RENOMEAR / SUBSTITUIR ===
        self.chk_substituir = QCheckBox("Substituir arquivos existentes (padrão: renomear)")
        layout.addWidget(self.chk_substituir)

        # === PASTA DE SAÍDA ===
        h_pasta = QHBoxLayout()
        self.txt_pasta = QLineEdit()
        self.txt_pasta.setText(os.path.join(QgsProject.instance().homePath(), "exports"))

        btn_pasta = QPushButton("Selecionar pasta")
        btn_pasta.clicked.connect(self.selecionar_pasta)

        h_pasta.addWidget(QLabel("Pasta de saída:"))
        h_pasta.addWidget(self.txt_pasta)
        h_pasta.addWidget(btn_pasta)

        layout.addLayout(h_pasta)

        # === BOTÃO EXPORTAR ===
        btn_exportar = QPushButton("Exportar")
        btn_exportar.clicked.connect(self.exportar)
        layout.addWidget(btn_exportar)

        self.setLayout(layout)

    # -----------------------------------------------------------
    def selecionar_pasta(self):
        pasta = QFileDialog.getExistingDirectory(self, "Escolha uma pasta")
        if pasta:
            self.txt_pasta.setText(pasta)

    # -----------------------------------------------------------
    def exportar(self):

        export_pdf = self.chk_pdf.isChecked()
        export_png = self.chk_png.isChecked()
        substituir = self.chk_substituir.isChecked()

        if not export_pdf and not export_png:
            QMessageBox.warning(self, "Erro", "Selecione ao menos um formato (PDF ou PNG).")
            return

        pasta = self.txt_pasta.text().strip()
        os.makedirs(pasta, exist_ok=True)

        project = QgsProject.instance()
        layouts = project.layoutManager().layouts()

        if not layouts:
            QMessageBox.warning(self, "Erro", "Nenhum layout encontrado.")
            return

        erros = []
        sucesso = 0

        for layout in layouts:

            nome = re.sub(r'[<>:"/\\|?*]', '', layout.name().strip())

            pdf_path = os.path.join(pasta, f"{nome}.pdf")
            png_path = os.path.join(pasta, f"{nome}.png")

            # Renomear caso necessário
            if not substituir:
                base = nome
                count = 1
                while (os.path.exists(pdf_path) or os.path.exists(png_path)):
                    nome = f"{base}_{count}"
                    pdf_path = os.path.join(pasta, f"{nome}.pdf")
                    png_path = os.path.join(pasta, f"{nome}.png")
                    count += 1

            try:
                exporter = QgsLayoutExporter(layout)

                ok_pdf = ok_png = True

                if export_pdf:
                    pdf_set = QgsLayoutExporter.PdfExportSettings()
                    r = exporter.exportToPdf(pdf_path, pdf_set)
                    ok_pdf = (r == QgsLayoutExporter.Success)

                if export_png:
                    png_set = QgsLayoutExporter.ImageExportSettings()
                    r = exporter.exportToImage(png_path, png_set)
                    ok_png = (r == QgsLayoutExporter.Success)

                if ok_pdf and ok_png:
                    sucesso += 1
                else:
                    erros.append(nome)

            except Exception as e:
                erros.append(f"{nome} → {e}")

        # ============================
        #   MENSAGEM FINAL COM LINK
        # ============================

        pasta_url = QUrl.fromLocalFile(pasta).toString()

        msg = QMessageBox(self)
        msg.setWindowTitle("Exportação concluída")
        msg.setIcon(QMessageBox.Information)
        msg.setTextFormat(Qt.RichText)

        texto = (
            f"<b>{sucesso}</b> layout(s) exportados com sucesso!<br><br>"
            f"<b>Pasta:</b> <a href='{pasta_url}'>{pasta}</a><br><br>"
            f"Clique no link acima para abrir a pasta."
        )

        if erros:
            texto += "<br><br><b>Com erros nos layouts:</b><br>" + "<br>".join(erros)

        msg.setText(texto)
        msg.setStandardButtons(QMessageBox.Ok)
        msg.exec()

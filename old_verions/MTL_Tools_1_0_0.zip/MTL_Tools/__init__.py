def classFactory(iface):
    from .MTL_Tools import MTL_Tools
    return MTL_Tools(iface)

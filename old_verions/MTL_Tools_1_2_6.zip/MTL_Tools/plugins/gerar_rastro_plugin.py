# -*- coding: utf-8 -*-
import os
from qgis.PyQt.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
    QComboBox, QDoubleSpinBox, QMessageBox, QCheckBox, QLineEdit, QFileDialog
)
from qgis.PyQt.QtGui import QIcon
from qgis.core import QgsProject
from ..utils.info_dialog import InfoDialog

from ..model.gerar_rastro_implemento import GerarRastroModel
from ..utils.preferences import load_tool_prefs, save_tool_prefs
from ..utils.tool_keys import ToolKey


class GerarRastroDialog(QDialog):
    TOOL_KEY = ToolKey.GERAR_RASTRO_IMPLEMENTO

    def __init__(self, iface):
        super().__init__(iface.mainWindow())
        self.iface = iface
        self.setWindowTitle("MTL Tools — Gerar Rastro Implemento")
        self.setMinimumWidth(360)
        icon_path = os.path.join(os.path.dirname(__file__), "..", "icons", "gerar_rastro.png")
        if os.path.exists(icon_path):
            self.setWindowIcon(QIcon(icon_path))

        self.model = GerarRastroModel()

        layout = QVBoxLayout()
        # -------------------------------------------------------
        # INFO BUTTON (canto superior direito)
        # -------------------------------------------------------
        info_layout = QHBoxLayout()
        info_layout.addStretch()

        btn_info = QPushButton("ℹ️")
        btn_info.setFixedWidth(30)
        btn_info.clicked.connect(self.show_info)
        info_layout.addWidget(btn_info)
        # Caminho do arquivo de instruções
        self.instructions_file = os.path.join(
            os.path.dirname(__file__), "instructions", "generate_trail_help.md"
        )

        layout.addLayout(info_layout)

        # input layer
        h1 = QHBoxLayout()
        h1.addWidget(QLabel("Camada de Linhas (INPUT):"))
        self.cmb_layers = QComboBox()
        h1.addWidget(self.cmb_layers)
        layout.addLayout(h1)

        # tamanhoimplemento
        h2 = QHBoxLayout()
        h2.addWidget(QLabel("Tamanho implemento:"))
        self.spin_tam = QDoubleSpinBox()
        self.spin_tam.setRange(0.000001, 999999)
        self.spin_tam.setValue(16.0)
        h2.addWidget(self.spin_tam)
        layout.addLayout(h2)

        # salvar em arquivo ou temporário (campo único: arquivo completo)
        h3 = QHBoxLayout()
        self.chk_save_file = QCheckBox('Salvar em arquivo (caso não marcado: camada temporária)')
        self.chk_save_file.stateChanged.connect(self._on_toggle_save_file)
        h3.addWidget(self.chk_save_file)
        layout.addLayout(h3)

        h4 = QHBoxLayout()
        h4.addWidget(QLabel('Salvar em (arquivo):'))
        self.txt_output_file = QLineEdit()
        h4.addWidget(self.txt_output_file)
        btn_file = QPushButton('...')
        btn_file.clicked.connect(self._pick_output_file)
        h4.addWidget(btn_file)
        layout.addLayout(h4)

        # aplicar estilo QML
        h_style = QHBoxLayout()
        self.chk_apply_style = QCheckBox('Aplicar estilo (QML) ao resultado')
        h_style.addWidget(self.chk_apply_style)
        layout.addLayout(h_style)

        h_qml = QHBoxLayout()
        h_qml.addWidget(QLabel('QML (opcional):'))
        self.txt_qml = QLineEdit()
        h_qml.addWidget(self.txt_qml)
        btn_qml = QPushButton('...')
        btn_qml.clicked.connect(self._pick_qml)
        h_qml.addWidget(btn_qml)
        layout.addLayout(h_qml)

        # buttons
        hb = QHBoxLayout()
        hb.addStretch()
        btn_run = QPushButton("Executar")
        btn_run.clicked.connect(self.on_run)
        hb.addWidget(btn_run)
        btn_close = QPushButton("Fechar")
        btn_close.clicked.connect(self.close)
        hb.addWidget(btn_close)
        layout.addLayout(hb)

        self.setLayout(layout)

        self._populate_layers()
        self._load_prefs()
        self._on_toggle_save_file(None)

    def _populate_layers(self):
        self.cmb_layers.clear()
        layers = QgsProject.instance().mapLayers().values()
        for lyr in layers:
            # only show vector layers
            try:
                if hasattr(lyr, 'wkbType'):
                    self.cmb_layers.addItem(lyr.name(), lyr.id())
            except Exception:
                continue
    # -------------------------------------------------------------
    #  INFO WINDOW
    # -------------------------------------------------------------
    def show_info(self):
        dlg = InfoDialog(self.instructions_file, self, "📘 Instruções – Gerar Rastro de Mauinas")
        dlg.exec()
    def _load_prefs(self):
        prefs = load_tool_prefs(self.TOOL_KEY)
        last_id = prefs.get('last_input_layer_id')
        last_tam = prefs.get('last_tamanhoimplemento')
        save_to_folder = prefs.get('save_to_folder', False)
        last_file = prefs.get('last_output_file', '')
        apply_style = prefs.get('apply_style', False)
        last_qml = prefs.get('last_qml_path', '')
        if last_tam is not None:
            try:
                self.spin_tam.setValue(float(last_tam))
            except Exception:
                pass
        if last_id:
            idx = self.cmb_layers.findData(last_id)
            if idx != -1:
                self.cmb_layers.setCurrentIndex(idx)
        try:
            self.chk_save_file.setChecked(bool(save_to_folder))
            self.txt_output_file.setText(last_file)
            self.chk_apply_style.setChecked(bool(apply_style))
            self.txt_qml.setText(last_qml)
        except Exception:
            pass

    def _save_prefs(self):
        data = {
            'last_input_layer_id': self.cmb_layers.currentData(),
            'last_tamanhoimplemento': float(self.spin_tam.value())
        }
        data['save_to_folder'] = bool(self.chk_save_file.isChecked())
        data['last_output_file'] = self.txt_output_file.text().strip()
        data['apply_style'] = bool(self.chk_apply_style.isChecked())
        data['last_qml_path'] = self.txt_qml.text().strip()
        save_tool_prefs(self.TOOL_KEY, data)

    def on_run(self):
        layer_id = self.cmb_layers.currentData()
        if not layer_id:
            QMessageBox.warning(self, 'Erro', 'Selecione uma camada de entrada válida.')
            return
        layer = QgsProject.instance().mapLayer(layer_id)
        if layer is None:
            QMessageBox.warning(self, 'Erro', 'Camada selecionada não encontrada.')
            return
        tam = float(self.spin_tam.value())
        save_to_folder = bool(self.chk_save_file.isChecked())
        out_file = self.txt_output_file.text().strip() if save_to_folder else None
        apply_style = bool(self.chk_apply_style.isChecked())
        qml_path = self.txt_qml.text().strip() or None
        try:
            out_layer = self.model.run(layer, tam, save_to_folder=save_to_folder, output_path=out_file)
            # Try to retrieve layer if model returned None
            if out_layer is None:
                # try find by name: if user saved to file, use filename stem, else default
                if out_file:
                    try:
                        from pathlib import Path
                        search_name = Path(out_file).stem
                    except Exception:
                        search_name = 'Rastro_Implemento'
                else:
                    search_name = 'Rastro_Implemento'
                layers = QgsProject.instance().mapLayersByName(search_name)
                out_layer = layers[0] if layers else None

            # apply style if requested
            if out_layer is not None and apply_style:
                try:
                    qml_to_use = qml_path
                    if not qml_to_use:
                        # default plugin style
                        qml_to_use = os.path.join(os.path.dirname(__file__), '..', 'styles', 'Rastro_Implemento.qml')
                        qml_to_use = os.path.normpath(qml_to_use)
                    if qml_to_use and os.path.exists(qml_to_use):
                        ok = out_layer.loadNamedStyle(qml_to_use)
                        # loadNamedStyle may return tuple
                        if isinstance(ok, tuple):
                            ok = ok[0]
                        if ok:
                            out_layer.triggerRepaint()
                except Exception:
                    pass

            QMessageBox.information(self, 'Concluído', 'Processamento executado (verifique a aba Histórico de processamento).')
            self._save_prefs()
        except Exception as e:
            QMessageBox.critical(self, 'Erro', f'Falha ao executar o modelo:\n{e}')

    def _on_toggle_save_file(self, state):
        checked = self.chk_save_file.isChecked()
        self.txt_output_file.setEnabled(checked)

    def _pick_output_file(self):
        # filters include common vector formats; QGIS will add drivers as available
        filters = "Shapefile (*.shp);;GeoPackage (*.gpkg);;GeoJSON (*.geojson *.json);;KML (*.kml);;CSV (*.csv)"
        f, _ = QFileDialog.getSaveFileName(self, 'Salvar como', self.txt_output_file.text() or '', filters)
        if f:
            self.txt_output_file.setText(f)

    def _pick_qml(self):
        f, _ = QFileDialog.getOpenFileName(self, 'Selecione arquivo QML', '', 'QML files (*.qml)')
        if f:
            self.txt_qml.setText(f)


def run_gerar_rastro(iface):
    dlg = GerarRastroDialog(iface)
    dlg.exec()

# -*- coding: utf-8 -*-
import os
from qgis.PyQt.QtWidgets import QAction, QMenu
from qgis.PyQt.QtGui import QIcon
from qgis.core import QgsApplication
from qgis.PyQt.QtWidgets import QAction, QMenu, QToolButton, QWidgetAction


from .processing.provider import MTLProvider


class MTL_Tools:
    def __init__(self, iface):
        self.iface = iface
        self.menu = None
        self.toolbar = None
        self.actions = []
        self.provider = None

    # =====================================================
    # INICIAR GUI E PROCESSING
    # =====================================================
    def initGui(self):

        # -------------------------
        # 1) ATIVAR PROCESSING PROVIDER
        # -------------------------
        self.provider = MTLProvider()
        QgsApplication.processingRegistry().addProvider(self.provider)

        # -------------------------
        # 2) CRIAR TOOLBAR EXCLUSIVA
        # -------------------------
        self.toolbar = self.iface.addToolBar("MTL Tools")
        self.toolbar.setObjectName("MTL_Tools_Toolbar")

        # -------------------------
        # 3) MENU PRINCIPAL
        # -------------------------
        self.menu = QMenu("MTL Tools", self.iface.mainWindow())

        # =====================================================
        # FERRAMENTA 1 – Export All Layouts
        # =====================================================
        export_icon = os.path.join(os.path.dirname(__file__), "icons", "export_icon.png")
        self.action_export_all = QAction(
            QIcon(export_icon),
            "Exportar todos os Layouts",
            self.iface.mainWindow()
        )
        self.action_export_all.triggered.connect(self.run_export_layouts)

        self.menu.addAction(self.action_export_all)
        self.iface.addPluginToMenu("MTL Tools", self.action_export_all)
        self.actions.append(self.action_export_all)

        # =====================================================
        # FERRAMENTA 2 – Replace in Layouts
        # =====================================================
        replace_icon = os.path.join(os.path.dirname(__file__), "icons", "replace_in_layouts.png")
        self.action_replace_layouts = QAction(
            QIcon(replace_icon),
            "Substituir textos nos Layouts",
            self.iface.mainWindow()
        )
        self.action_replace_layouts.triggered.connect(self.run_replace_layouts)

        self.menu.addAction(self.action_replace_layouts)
        self.iface.addPluginToMenu("MTL Tools", self.action_replace_layouts)
        self.actions.append(self.action_replace_layouts)

        # =====================================================
        # FERRAMENTA 3 – Restart QGIS
        # =====================================================
        restart_icon = os.path.join(os.path.dirname(__file__), "icons", "restart_qgis.png")
        self.action_restart_qgis = QAction(
            QIcon(restart_icon),
            "Salvar, Fechar e Reabrir Projeto",
            self.iface.mainWindow()
        )
        self.action_restart_qgis.triggered.connect(self.run_restart_qgis)

        self.menu.addAction(self.action_restart_qgis)
        self.iface.addPluginToMenu("MTL Tools", self.action_restart_qgis)
        self.actions.append(self.action_restart_qgis)

        # =====================================================
        # FERRAMENTA 4 – Carregar pasta de arquivos
        # =====================================================
        load_icon = os.path.join(os.path.dirname(__file__), "icons", "load_folder.png")
        self.action_load_folder = QAction(
            QIcon(load_icon),
            "Carregar pasta de arquivos",
            self.iface.mainWindow()
        )
        self.action_load_folder.triggered.connect(self.run_load_folder)

        self.menu.addAction(self.action_load_folder)
        self.iface.addPluginToMenu("MTL Tools", self.action_load_folder)
        self.actions.append(self.action_load_folder)

        # =====================================================
        # FERRAMENTA 5 – Gerar Rastro Implemento
        # =====================================================
        gerar_icon = os.path.join(os.path.dirname(__file__), "icons", "gerar_rastro.png")
        self.action_gerar_rastro = QAction(
            QIcon(gerar_icon),
            "Gerar Rastro Implemento",
            self.iface.mainWindow()
        )
        self.action_gerar_rastro.triggered.connect(self.run_gerar_rastro)

        self.menu.addAction(self.action_gerar_rastro)
        self.iface.addPluginToMenu("MTL Tools", self.action_gerar_rastro)
        self.actions.append(self.action_gerar_rastro)
        
        # =====================================================
        # FERRAMENTA 6 – About Dialog
        # =====================================================
        gerar_icon = os.path.join(os.path.dirname(__file__), "icons", "about.png")
        self.action_about_dialog = QAction(
            QIcon(gerar_icon),
            "Sobre o MTL Tools",
            self.iface.mainWindow()
        )
        self.action_about_dialog.triggered.connect(self.run_about_dialog)

        self.menu.addAction(self.action_about_dialog)
        self.iface.addPluginToMenu("MTL Tools", self.action_about_dialog)
        self.actions.append(self.action_about_dialog)
        
        # =====================================================
        # FERRAMENTA 7 – Obter Coordenadas ao Clicar no Mapa
        # =====================================================
        coord_icon = os.path.join(os.path.dirname(__file__), "icons", "coord.png")
        self.action_coord_click = QAction(
            QIcon(coord_icon),
            "Capturar Coordenadas",
            self.iface.mainWindow()
        )
        self.action_coord_click.triggered.connect(self.run_coord_click)

        self.menu.addAction(self.action_coord_click)
        self.iface.addPluginToMenu("MTL Tools", self.action_coord_click)
        self.actions.append(self.action_coord_click)

        

        # =====================================================
        # GRUPO ESTRUTURA TOOLBAR
        # =====================================================

        # =====================================================
        # GRUPO 1 – Sistema
        # =====================================================
        self.toolbar.addAction(self.action_restart_qgis)
        # =====================================================
        # GRUPO 2 – Layouts (Botão com dropdown)
        # =====================================================

        # Menu do grupo Layouts
        layouts_menu = QMenu(self.iface.mainWindow())
        layouts_menu.addAction(self.action_export_all)
        layouts_menu.addAction(self.action_replace_layouts)

        # Botão com seta
        layouts_button = QToolButton()
        layouts_button.setText("Layouts")
        layouts_button.setIcon(self.action_export_all.icon())
        layouts_button.setMenu(layouts_menu)

        # Comportamento:
        # - Clica no botão → ação principal
        # - Clica na seta → abre menu
        layouts_button.setPopupMode(QToolButton.MenuButtonPopup)
        layouts_button.clicked.connect(self.run_export_layouts)

        # Wrapper para inserir na toolbar
        layouts_widget_action = QWidgetAction(self.toolbar)
        layouts_widget_action.setDefaultWidget(layouts_button)

        self.toolbar.addAction(layouts_widget_action)
    

        # =====================================================
        # GRUPO 3 – Camadas
        # =====================================================
        self.toolbar.addAction(self.action_load_folder)
        self.toolbar.addSeparator()
        
        # =====================================================
        # GRUPO 4 – Vetores
        self.toolbar.addAction(self.action_coord_click)
        self.toolbar.addSeparator()
                
        # =====================================================
        # GRUPO 5 – Agricultura de Precisão
        # =====================================================
        self.toolbar.addAction(self.action_gerar_rastro)

        self.toolbar.addSeparator()
        # =====================================================
        # GRUPO 6 - Raster
        # =====================================================
        

        self.toolbar.addSeparator()



    # =====================================================
    # DESCARREGAR PLUGIN
    # =====================================================
    def unload(self):

        # Remover provider do Processing
        if self.provider:
            QgsApplication.processingRegistry().removeProvider(self.provider)

        # Remover ações do menu e toolbar
        for act in self.actions:
            self.iface.removePluginMenu("MTL Tools", act)
            self.iface.removeToolBarIcon(act)

        # Remover toolbar
        if self.toolbar:
            del self.toolbar

    # =====================================================
    # EXECUTAR: Export All Layouts
    # ===============================================   ======
    def run_export_layouts(self):
        from .plugins.export_all_layouts import ExportAllLayoutsDialog
        dlg = ExportAllLayoutsDialog(self.iface)
        dlg.exec()

    # =====================================================
    # EXECUTAR: Replace Text in Layouts
    # =====================================================
    def run_replace_layouts(self):
        from .plugins.replace_in_layouts import run_replace_in_layouts
        run_replace_in_layouts(self.iface)

    # =====================================================
    # EXECUTAR: Restart QGIS
    # =====================================================
    def run_restart_qgis(self):
        from .plugins.restart_qgis import run_restart_qgis
        run_restart_qgis(self.iface)

    # =====================================================
    # EXECUTAR: Load Folder Layers
    # =====================================================
    def run_load_folder(self):
        from .plugins.load_folder_layers import run_load_folder_layers
        run_load_folder_layers(self.iface)

    # =====================================================
    # EXECUTAR: Gerar Rastro Implemento (painel)
    # =====================================================
    def run_gerar_rastro(self):
        from .plugins.gerar_rastro_plugin import run_gerar_rastro
        run_gerar_rastro(self.iface)
        
    # =====================================================
    # EXECUTAR: About Dialog
    # =====================================================
    def run_about_dialog(self):
        from .plugins.about_dialog import run_about_dialog
        run_about_dialog(self.iface)
        
    # =====================================================
    # EXECUTAR: Obter Coordenadas ao Clicar no Mapa
    # =====================================================
    def run_coord_click(self):
        from .plugins.coord_click_tool import CoordClickTool

        # manter referência viva
        self.coord_click_tool = CoordClickTool(self.iface)

        self.iface.mapCanvas().setMapTool(self.coord_click_tool)


